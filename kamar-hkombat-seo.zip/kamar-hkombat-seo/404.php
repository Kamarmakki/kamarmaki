<?php
/**
 * قالب صفحة الخطأ 404
 */
get_header(); ?>

<div class="container section-padding">
    <div class="error-404 not-found">
        <header class="page-header">
            <h1 class="page-title"><?php _e('عذراً، الصفحة غير موجودة', 'kamar-hkombat'); ?></h1>
        </header>
        
        <div class="page-content">
            <p><?php _e('يبدو أن الصفحة التي تبحث عنها غير موجودة. جرب البحث في الموقع:', 'kamar-hkombat'); ?></p>
            
            <?php get_search_form(); ?>
            
            <div class="text-center mt-4">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">العودة للصفحة الرئيسية</a>
            </div>
        </div>
    </div>
</div>

<?php get_footer();