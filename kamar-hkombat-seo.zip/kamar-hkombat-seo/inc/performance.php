<?php
/**
 * تحسينات الأداء
 */

// إزالة استعلامات غير ضرورية
function kamar_hkombat_disable_emojis() {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
}
add_action('init', 'kamar_hkombat_disable_emojis');

// إزالة إصدار الملفات من URL
function kamar_hkombat_remove_script_version($src) {
    if (strpos($src, 'ver=')) {
        $src = remove_query_arg('ver', $src);
    }
    return $src;
}
add_filter('script_loader_src', 'kamar_hkombat_remove_script_version', 15, 1);
add_filter('style_loader_src', 'kamar_hkombat_remove_script_version', 15, 1);

// تعطيل الـ Embeds
function kamar_hkombat_disable_embeds_code_init() {
    remove_action('rest_api_init', 'wp_oembed_register_route');
    remove_filter('oembed_dataparse', 'wp_filter_oembed_result', 10);
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'wp_oembed_add_host_js');
}
add_action('init', 'kamar_hkombat_disable_embeds_code_init', 9999);

// تحميل JavaScript في التذييل
function kamar_hkombat_move_js_to_footer() {
    if (!is_admin()) {
        wp_deregister_script('jquery');
        wp_register_script('jquery', includes_url('/js/jquery/jquery.js'), false, null, true);
    }
}
add_action('wp_enqueue_scripts', 'kamar_hkombat_move_js_to_footer');

// تفعيل التخزين المؤقت للمتصفح
function kamar_hkombat_cache_busting($src) {
    if (strpos($src, get_template_directory_uri()) !== false) {
        $src = $src . '?v=' . filemtime(get_template_directory());
    }
    return $src;
}
add_filter('style_loader_src', 'kamar_hkombat_cache_busting');
add_filter('script_loader_src', 'kamar_hkombat_cache_busting');