<?php
/**
 * إعدادات القالب الأساسية
 */

function kamar_hkombat_theme_setup() {
    // إضافة دعم العناوين المخصصة
    add_theme_support('title-tag');
    
    // إضافة دعم الصور المصغرة
    add_theme_support('post-thumbnails');
    
    // إضافة أبعاد صور مخصصة
    add_image_size('kamar-hkombat-hero', 1920, 800, true);
    add_image_size('kamar-hkombat-service', 400, 300, true);
    add_image_size('kamar-hkombat-team', 300, 300, true);
    add_image_size('kamar-hkombat-blog', 800, 500, true);
    
    // إضافة دعم الشعارات المخصصة
    add_theme_support('custom-logo', array(
        'height'      => 50,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // إضافة دعم الرأس المخصص
    add_theme_support('custom-header', array(
        'default-image' => get_template_directory_uri() . '/images/hero-bg.jpg',
        'width'         => 1920,
        'height'        => 800,
        'flex-height'   => true,
        'header-text'   => false,
    ));
    
    // إضافة دعم الخلفية المخصصة
    add_theme_support('custom-background', array(
        'default-color' => 'f7f7f7',
    ));
    
    // إضافة دعم تنسيقات المشاركة
    add_theme_support('post-formats', array(
        'aside', 'image', 'gallery', 'video', 'audio', 'quote', 'link', 'status'
    ));
    
    // إضافة دعم HTML5
    add_theme_support('html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
    ));
    
    // إضافة دعم محرر الكتل
    add_theme_support('align-wide');
    add_theme_support('editor-styles');
    add_theme_support('wp-block-styles');
    add_theme_support('responsive-embeds');
    
    // إضافة دعم ألوان المحرر
    add_theme_support('editor-color-palette', array(
        array(
            'name' => 'أزرق أساسي',
            'slug' => 'primary',
            'color' => '#1a237e',
        ),
        array(
            'name' => 'ذهبي',
            'slug' => 'secondary',
            'color' => '#d4af37',
        ),
        array(
            'name' => 'أبيض',
            'slug' => 'white',
            'color' => '#ffffff',
        ),
        array(
            'name' => 'أسود',
            'slug' => 'black',
            'color' => '#000000',
        ),
    ));
    
    // إضافة دعم أحجام خطوط المحرر
    add_theme_support('editor-font-sizes', array(
        array('name' => 'صغير', 'size' => 12, 'slug' => 'small'),
        array('name' => 'عادي', 'size' => 16, 'slug' => 'normal'),
        array('name' => 'كبير', 'size' => 20, 'slug' => 'large'),
        array('name' => 'كبير جداً', 'size' => 24, 'slug' => 'huge')
    ));
    
    // تسجيل القوائم
    register_nav_menus(array(
        'primary'   => __('القائمة الرئيسية', 'kamar-hkombat'),
        'footer'    => __('قائمة التذييل', 'kamar-hkombat'),
        'mobile'    => __('قائمة الجوال', 'kamar-hkombat'),
    ));
}
add_action('after_setup_theme', 'kamar_hkombat_theme_setup');

// تحميل مجلد اللغات
function kamar_hkombat_load_textdomain() {
    load_theme_textdomain('kamar-hkombat', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'kamar_hkombat_load_textdomain');