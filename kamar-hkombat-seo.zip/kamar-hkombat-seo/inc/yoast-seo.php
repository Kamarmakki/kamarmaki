<?php
/**
 * دعم Yoast SEO
 */

// إضافة breadcrumbs مخصصة
function kamar_hkombat_yoast_breadcrumbs() {
    if (function_exists('yoast_breadcrumb')) {
        yoast_breadcrumb('<nav class="breadcrumb">', '</nav>');
    }
}

// تخصيص عنوان SEO
function kamar_hkombat_custom_seo_title($title) {
    if (is_front_page()) {
        return 'Kamar Hkombat SEO - أول منصة عربية متكاملة لخدمات السيو';
    }
    return $title;
}
add_filter('wpseo_title', 'kamar_hkombat_custom_seo_title');

// تخصيص وصف SEO
function kamar_hkombat_custom_seo_description($description) {
    if (is_front_page()) {
        return 'حقّق أعلى تصنيف في جوجل مع خدمات تحسين محركات البحث الاحترافية من Kamar Hkombat SEO';
    }
    return $description;
}
add_filter('wpseo_metadesc', 'kamar_hkombat_custom_seo_description');

// إضافة كلمات مفتاحية مخصصة
function kamar_hkombat_custom_seo_keywords($metakeywords) {
    if (is_front_page()) {
        return 'سيو, تحسين محركات البحث, خدمات السيو, Kamar Hkombat SEO';
    }
    return $metakeywords;
}
add_filter('wpseo_metakeywords', 'kamar_hkombat_custom_seo_keywords');