<?php
/**
 * Theme hooks
 *
 * @package Kamar_Hkombat
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Theme Setup Hooks
 */
add_action('after_setup_theme', 'kamar_hkombat_setup');
add_action('widgets_init', 'kamar_hkombat_widgets_init');
add_action('wp_enqueue_scripts', 'kamar_hkombat_scripts');
add_action('wp_enqueue_scripts', 'kamar_hkombat_styles');

/**
 * Header Hooks
 */
add_action('kamar_hkombat_header', 'kamar_hkombat_site_branding');
add_action('kamar_hkombat_header', 'kamar_hkombat_primary_navigation');
add_action('kamar_hkombat_header', 'kamar_hkombat_header_search');

/**
 * Content Hooks
 */
add_action('kamar_hkombat_before_content', 'kamar_hkombat_breadcrumb');
add_action('kamar_hkombat_before_entry_content', 'kamar_hkombat_post_thumbnail');
add_action('kamar_hkombat_entry_content', 'kamar_hkombat_entry_meta');
add_action('kamar_hkombat_after_entry_content', 'kamar_hkombat_entry_footer');

/**
 * Footer Hooks
 */
add_action('kamar_hkombat_footer', 'kamar_hkombat_footer_widgets');
add_action('kamar_hkombat_footer', 'kamar_hkombat_footer_info');
add_action('kamar_hkombat_footer', 'kamar_hkombat_social_links');

/**
 * Sidebar Hooks
 */
add_action('kamar_hkombat_sidebar', 'kamar_hkombat_get_sidebar');

/**
 * Comment Hooks
 */
add_action('comment_form_before', 'kamar_hkombat_comment_form_before');
add_action('comment_form_after', 'kamar_hkombat_comment_form_after');
add_action('comment_form_top', 'kamar_hkombat_comment_form_top');
add_action('comment_form_logged_in_after', 'kamar_hkombat_comment_form_logged_in_after');
add_action('comment_form_fields', 'kamar_hkombat_comment_form_fields');

/**
 * WordPress Core Hooks
 */
add_filter('body_class', 'kamar_hkombat_body_classes');
add_filter('post_class', 'kamar_hkombat_post_classes');
add_filter('excerpt_more', 'kamar_hkombat_excerpt_more');
add_filter('excerpt_length', 'kamar_hkombat_excerpt_length');
add_filter('wp_nav_menu_args', 'kamar_hkombat_nav_menu_args');
add_filter('nav_menu_css_class', 'kamar_hkombat_nav_menu_css_class', 10, 2);
add_filter('nav_menu_link_attributes', 'kamar_hkombat_nav_menu_link_attributes', 10, 4);
add_filter('the_content_more_link', 'kamar_hkombat_content_more_link');
add_filter('get_the_archive_title', 'kamar_hkombat_archive_title');
add_filter('document_title_separator', 'kamar_hkombat_document_title_separator');
add_filter('document_title_parts', 'kamar_hkombat_document_title_parts');

/**
 * Custom Hooks
 */
do_action('kamar_hkombat_before_header');
do_action('kamar_hkombat_header');
do_action('kamar_hkombat_after_header');

do_action('kamar_hkombat_before_content');
do_action('kamar_hkombat_content');
do_action('kamar_hkombat_after_content');

do_action('kamar_hkombat_before_sidebar');
do_action('kamar_hkombat_sidebar');
do_action('kamar_hkombat_after_sidebar');

do_action('kamar_hkombat_before_footer');
do_action('kamar_hkombat_footer');
do_action('kamar_hkombat_after_footer');

do_action('kamar_hkombat_before_entry');
do_action('kamar_hkombat_entry');
do_action('kamar_hkombat_after_entry');

do_action('kamar_hkombat_before_entry_content');
do_action('kamar_hkombat_entry_content');
do_action('kamar_hkombat_after_entry_content');

do_action('kamar_hkombat_before_entry_header');
do_action('kamar_hkombat_entry_header');
do_action('kamar_hkombat_after_entry_header');

do_action('kamar_hkombat_before_entry_meta');
do_action('kamar_hkombat_entry_meta');
do_action('kamar_hkombat_after_entry_meta');

do_action('kamar_hkombat_before_entry_footer');
do_action('kamar_hkombat_entry_footer');
do_action('kamar_hkombat_after_entry_footer');