<?php
/**
 * Browser-specific functions
 *
 * @package Kamar_Hkombat
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Browser detection
 */
function kamar_hkombat_browser_detection() {
    global $is_lynx, $is_gecko, $is_IE, $is_opera, $is_NS4, $is_safari, $is_chrome, $is_iphone;

    $browser_class = '';

    if ($is_lynx) {
        $browser_class = 'lynx';
    } elseif ($is_gecko) {
        $browser_class = 'gecko';
    } elseif ($is_opera) {
        $browser_class = 'opera';
    } elseif ($is_NS4) {
        $browser_class = 'ns4';
    } elseif ($is_safari) {
        $browser_class = 'safari';
    } elseif ($is_chrome) {
        $browser_class = 'chrome';
    } elseif ($is_IE) {
        $browser_class = 'ie';
    } else {
        $browser_class = 'unknown';
    }

    if ($is_iphone) {
        $browser_class .= ' iphone';
    }

    return $browser_class;
}

/**
 * Add browser class to body
 */
function kamar_hkombat_browser_body_class($classes) {
    $browser = kamar_hkombat_browser_detection();
    $classes[] = $browser;
    return $classes;
}
add_filter('body_class', 'kamar_hkombat_browser_body_class');

/**
 * IE specific styles
 */
function kamar_hkombat_ie_styles() {
    global $is_IE;
    
    if ($is_IE) {
        wp_enqueue_style('kamar-hkombat-ie', get_template_directory_uri() . '/css/ie.css', array(), KAMAR_HKOMBAT_VERSION);
        wp_style_add_data('kamar-hkombat-ie', 'conditional', 'IE');
    }
}
add_action('wp_enqueue_scripts', 'kamar_hkombat_ie_styles');

/**
 * Safari specific fixes
 */
function kamar_hkombat_safari_fixes() {
    global $is_safari;
    
    if ($is_safari) {
        ?>
        <style>
            /* Safari specific styles */
            .safari .some-element {
                /* Safari specific fix */
            }
        </style>
        <?php
    }
}
add_action('wp_head', 'kamar_hkombat_safari_fixes');

/**
 * Chrome specific fixes
 */
function kamar_hkombat_chrome_fixes() {
    global $is_chrome;
    
    if ($is_chrome) {
        ?>
        <style>
            /* Chrome specific styles */
            .chrome .some-element {
                /* Chrome specific fix */
            }
        </style>
        <?php
    }
}
add_action('wp_head', 'kamar_hkombat_chrome_fixes');

/**
 * Firefox specific fixes
 */
function kamar_hkombat_firefox_fixes() {
    global $is_gecko;
    
    if ($is_gecko) {
        ?>
        <style>
            /* Firefox specific styles */
            .gecko .some-element {
                /* Firefox specific fix */
            }
        </style>
        <?php
    }
}
add_action('wp_head', 'kamar_hkombat_firefox_fixes');

/**
 * Mobile detection
 */
function kamar_hkombat_is_mobile() {
    return (bool) preg_match('/(android|iphone|ipod|ipad|ios|blackberry|webos|windows phone)/i', $_SERVER['HTTP_USER_AGENT']);
}

/**
 * Tablet detection
 */
function kamar_hkombat_is_tablet() {
    return (bool) preg_match('/(ipad|tablet|kindle|silk|playbook)/i', $_SERVER['HTTP_USER_AGENT']);
}

/**
 * Add mobile class to body
 */
function kamar_hkombat_mobile_body_class($classes) {
    if (kamar_hkombat_is_mobile()) {
        $classes[] = 'mobile';
    }
    
    if (kamar_hkombat_is_tablet()) {
        $classes[] = 'tablet';
    }
    
    return $classes;
}
add_filter('body_class', 'kamar_hkombat_mobile_body_class');

/**
 * Device specific scripts
 */
function kamar_hkombat_device_scripts() {
    if (kamar_hkombat_is_mobile()) {
        wp_enqueue_script('kamar-hkombat-mobile', get_template_directory_uri() . '/js/mobile.js', array('jquery'), KAMAR_HKOMBAT_VERSION, true);
    }
    
    if (kamar_hkombat_is_tablet()) {
        wp_enqueue_script('kamar-hkombat-tablet', get_template_directory_uri() . '/js/tablet.js', array('jquery'), KAMAR_HKOMBAT_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'kamar_hkombat_device_scripts');

/**
 * Viewport meta tag for mobile
 */
function kamar_hkombat_mobile_viewport() {
    if (kamar_hkombat_is_mobile()) {
        echo '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">';
    } else {
        echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    }
}
add_action('wp_head', 'kamar_hkombat_mobile_viewport', 1);

/**
 * Touch device detection
 */
function kamar_hkombat_is_touch_device() {
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0;
}

/**
 * Add touch class to body
 */
function kamar_hkombat_touch_body_class($classes) {
    if (kamar_hkombat_is_touch_device()) {
        $classes[] = 'touch-device';
    } else {
        $classes[] = 'no-touch';
    }
    
    return $classes;
}
add_filter('body_class', 'kamar_hkombat_touch_body_class');

/**
 * Retina display detection
 */
function kamar_hkombat_is_retina() {
    return isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/Macintosh|Mac OS X/', $_SERVER['HTTP_USER_AGENT']) && isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/AppleWebKit/', $_SERVER['HTTP_USER_AGENT']);
}

/**
 * Add retina class to body
 */
function kamar_hkombat_retina_body_class($classes) {
    if (kamar_hkombat_is_retina()) {
        $classes[] = 'retina';
    }
    
    return $classes;
}
add_filter('body_class', 'kamar_hkombat_retina_body_class');