<?php
/**
 * معالجة نموذج الاتصال
 */

function kamar_hkombat_contact_form_handler() {
    // التحقق من nonce
    if (!isset($_POST['contact_nonce']) || !wp_verify_nonce($_POST['contact_nonce'], 'contact_form')) {
        wp_die('فشل التحقق من الأمان');
    }
    
    // تنظيف والتحقق من البيانات
    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
    $website = isset($_POST['website']) ? esc_url($_POST['website']) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';
    $service = isset($_POST['service']) ? sanitize_text_field($_POST['service']) : '';
    
    // التحقق من الحقول المطلوبة
    if (empty($name) || empty($email) || empty($message)) {
        wp_die('يرجى ملء جميع الحقول المطلوبة');
    }
    
    if (!is_email($email)) {
        wp_die('يرجى إدخال بريد إلكتروني صحيح');
    }
    
    // إعداد البريد الإلكتروني
    $to = get_option('admin_email');
    $subject = sprintf('طلب جديد من %s - Kamar Hkombat SEO', $name);
    
    $body = "طلب جديد من موقع Kamar Hkombat SEO\n\n";
    $body .= "اسم العميل: $name\n";
    $body .= "البريد الإلكتروني: $email\n";
    $body .= "رقم الهاتف: $phone\n";
    $body .= "الموقع: $website\n";
    $body .= "الخدمة المطلوبة: $service\n\n";
    $body .= "الرسالة:\n$message\n\n";
    $body .= "تاريخ الطلب: " . date('Y-m-d H:i:s') . "\n";
    $body .= "عنوان IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
    
    // إعداد الرؤوس
    $headers = array(
        'Content-Type: text/plain; charset=UTF-8',
        'From: ' . $name . ' <' . $email . '>',
        'Reply-To: ' . $email,
    );
    
    // إرسال البريد الإلكتروني
    $sent = wp_mail($to, $subject, $body, $headers);
    
    if ($sent) {
        // حفظ الطلب في قاعدة البيانات
        $post_data = array(
            'post_title'   => 'طلب من: ' . $name,
            'post_content' => $body,
            'post_status'  => 'private',
            'post_type'    => 'contact_request',
            'post_author'  => 1,
        );
        
        wp_insert_post($post_data);
        
        // إعادة التوجيه مع رسالة نجاح
        wp_redirect(add_query_arg('contact_success', '1', wp_get_referer()));
    } else {
        wp_redirect(add_query_arg('contact_error', '1', wp_get_referer()));
    }
    
    exit;
}
add_action('admin_post_nopriv_contact_form', 'kamar_hkombat_contact_form_handler');
add_action('admin_post_contact_form', 'kamar_hkombat_contact_form_handler');

// عرض رسائل النجاح والخطأ
function kamar_hkombat_contact_form_messages() {
    if (isset($_GET['contact_success']) && $_GET['contact_success'] == '1') {
        echo '<div class="alert alert-success">تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.</div>';
    }
    
    if (isset($_GET['contact_error']) && $_GET['contact_error'] == '1') {
        echo '<div class="alert alert-danger">حدث خطأ أثناء إرسال رسالتك. يرجى المحاولة مرة أخرى.</div>';
    }
}
add_action('wp_footer', 'kamar_hkombat_contact_form_messages');

// تسجيل نوع منشور مخصص لطلبات الاتصال
function kamar_hkombat_register_contact_post_type() {
    register_post_type('contact_request', array(
        'labels'        => array(
            'name'          => 'طلبات الاتصال',
            'singular_name' => 'طلب اتصال',
        ),
        'public'        => false,
        'show_ui'       => true,
        'capability'    => 'manage_options',
        'supports'      => array('title', 'editor'),
        'menu_icon'     => 'dashicons-email-alt',
    ));
}
add_action('init', 'kamar_hkombat_register_contact_post_type');