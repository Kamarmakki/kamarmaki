<?php
/**
 * Customizer settings
 *
 * @package Kamar_Hkombat
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function kamar_hkombat_customize_register($wp_customize) {
    // Site Identity
    $wp_customize->get_setting('blogname')->transport         = 'postMessage';
    $wp_customize->get_setting('blogdescription')->transport  = 'postMessage';
    $wp_customize->get_setting('header_textcolor')->transport = 'postMessage';

    if (isset($wp_customize->selective_refresh)) {
        $wp_customize->selective_refresh->add_partial('blogname', array(
            'selector'        => '.site-title a',
            'render_callback' => 'kamar_hkombat_customize_partial_blogname',
        ));
        $wp_customize->selective_refresh->add_partial('blogdescription', array(
            'selector'        => '.site-description',
            'render_callback' => 'kamar_hkombat_customize_partial_blogdescription',
        ));
    }

    // Hero Section
    $wp_customize->add_section('kamar_hkombat_hero_section', array(
        'title'    => __('Hero Section', 'kamar-hkombat'),
        'priority' => 30,
    ));

    // Hero Title
    $wp_customize->add_setting('kamar_hkombat_hero_title', array(
        'default'           => 'أول منصة عربية متكاملة لخدمات السيو',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control('kamar_hkombat_hero_title', array(
        'label'    => __('Hero Title', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_hero_section',
        'type'     => 'text',
    ));

    // Hero Subtitle
    $wp_customize->add_setting('kamar_hkombat_hero_subtitle', array(
        'default'           => 'حقّق أعلى تصنيف في جوجل مع خدمات تحسين محركات البحث الاحترافية',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control('kamar_hkombat_hero_subtitle', array(
        'label'    => __('Hero Subtitle', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_hero_section',
        'type'     => 'textarea',
    ));

    // Hero Button 1 Text
    $wp_customize->add_setting('kamar_hkombat_hero_button1_text', array(
        'default'           => 'ابدأ الآن',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control('kamar_hkombat_hero_button1_text', array(
        'label'    => __('Button 1 Text', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_hero_section',
        'type'     => 'text',
    ));

    // Hero Button 1 URL
    $wp_customize->add_setting('kamar_hkombat_hero_button1_url', array(
        'default'           => '#contact',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control('kamar_hkombat_hero_button1_url', array(
        'label'    => __('Button 1 URL', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_hero_section',
        'type'     => 'text',
    ));

    // Hero Button 2 Text
    $wp_customize->add_setting('kamar_hkombat_hero_button2_text', array(
        'default'           => 'تعرف على خدماتنا',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control('kamar_hkombat_hero_button2_text', array(
        'label'    => __('Button 2 Text', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_hero_section',
        'type'     => 'text',
    ));

    // Hero Button 2 URL
    $wp_customize->add_setting('kamar_hkombat_hero_button2_url', array(
        'default'           => '#services',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control('kamar_hkombat_hero_button2_url', array(
        'label'    => __('Button 2 URL', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_hero_section',
        'type'     => 'text',
    ));

    // Hero Background
    $wp_customize->add_setting('kamar_hkombat_hero_background', array(
        'default'           => get_template_directory_uri() . '/images/hero-bg.jpg',
        'sanitize_callback' => 'esc_url_raw',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'kamar_hkombat_hero_background', array(
        'label'    => __('Hero Background', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_hero_section',
        'settings' => 'kamar_hkombat_hero_background',
    )));

    // Colors
    $wp_customize->add_section('colors', array(
        'title'    => __('Colors', 'kamar-hkombat'),
        'priority' => 40,
    ));

    // Primary Color
    $wp_customize->add_setting('kamar_hkombat_primary_color', array(
        'default'           => '#1a237e',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'kamar_hkombat_primary_color', array(
        'label'    => __('Primary Color', 'kamar-hkombat'),
        'section'  => 'colors',
        'settings' => 'kamar_hkombat_primary_color',
    )));

    // Secondary Color
    $wp_customize->add_setting('kamar_hkombat_secondary_color', array(
        'default'           => '#d4af37',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'kamar_hkombat_secondary_color', array(
        'label'    => __('Secondary Color', 'kamar-hkombat'),
        'section'  => 'colors',
        'settings' => 'kamar_hkombat_secondary_color',
    )));

    // Footer Options
    $wp_customize->add_section('kamar_hkombat_footer_options', array(
        'title'    => __('Footer Options', 'kamar-hkombat'),
        'priority' => 120,
    ));

    // Footer Columns
    $wp_customize->add_setting('kamar_hkombat_footer_columns', array(
        'default'           => 4,
        'sanitize_callback' => 'absint',
        'transport'         => 'refresh',
    ));

    $wp_customize->add_control('kamar_hkombat_footer_columns', array(
        'label'    => __('Footer Columns', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_footer_options',
        'type'     => 'select',
        'choices'  => array(
            1 => __('1 Column', 'kamar-hkombat'),
            2 => __('2 Columns', 'kamar-hkombat'),
            3 => __('3 Columns', 'kamar-hkombat'),
            4 => __('4 Columns', 'kamar-hkombat'),
        ),
    ));

    // Copyright Text
    $wp_customize->add_setting('kamar_hkombat_copyright_text', array(
        'default'           => sprintf(__('&copy; %s Kamar Hkombat SEO. All rights reserved.', 'kamar-hkombat'), date('Y')),
        'sanitize_callback' => 'wp_kses_post',
        'transport'         => 'postMessage',
    ));

    $wp_customize->add_control('kamar_hkombat_copyright_text', array(
        'label'    => __('Copyright Text', 'kamar-hkombat'),
        'section'  => 'kamar_hkombat_footer_options',
        'type'     => 'textarea',
    ));
}
add_action('customize_register', 'kamar_hkombat_customize_register');

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function kamar_hkombat_customize_partial_blogname() {
    bloginfo('name');
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function kamar_hkombat_customize_partial_blogdescription() {
    bloginfo('description');
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function kamar_hkombat_customize_preview_js() {
    wp_enqueue_script('kamar-hkombat-customizer', get_template_directory_uri() . '/js/customizer.js', array('customize-preview'), KAMAR_HKOMBAT_VERSION, true);
}
add_action('customize_preview_init', 'kamar_hkombat_customize_preview_js');