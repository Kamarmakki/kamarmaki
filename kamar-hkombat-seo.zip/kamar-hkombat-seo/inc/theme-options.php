<?php
/**
 * خيارات القالب
 */

// تسجيل إعدادات القالب
function kamar_hkombat_theme_options_init() {
    register_setting('kamar_hkombat_theme_options', 'kamar_hkombat_theme_options');
    
    // إعدادات عامة
    add_settings_section(
        'kamar_hkombat_general_settings',
        'الإعدادات العامة',
        'kamar_hkombat_general_settings_callback',
        'kamar_hkombat_theme_options'
    );
    
    add_settings_field(
        'logo_text',
        'نص الشعار',
        'kamar_hkombat_text_field_callback',
        'kamar_hkombat_theme_options',
        'kamar_hkombat_general_settings',
        array('field' => 'logo_text')
    );
    
    add_settings_field(
        'phone_number',
        'رقم الهاتف',
        'kamar_hkombat_text_field_callback',
        'kamar_hkombat_theme_options',
        'kamar_hkombat_general_settings',
        array('field' => 'phone_number')
    );
    
    add_settings_field(
        'email_address',
        'البريد الإلكتروني',
        'kamar_hkombat_email_field_callback',
        'kamar_hkombat_theme_options',
        'kamar_hkombat_general_settings',
        array('field' => 'email_address')
    );
    
    add_settings_field(
        'address',
        'العنوان',
        'kamar_hkombat_textarea_field_callback',
        'kamar_hkombat_theme_options',
        'kamar_hkombat_general_settings',
        array('field' => 'address')
    );
    
    add_settings_field(
        'working_hours',
        'ساعات العمل',
        'kamar_hkombat_text_field_callback',
        'kamar_hkombat_theme_options',
        'kamar_hkombat_general_settings',
        array('field' => 'working_hours')
    );
    
    // إعدادات وسائل التواصل الاجتماعي
    add_settings_section(
        'kamar_hkombat_social_settings',
        'وسائل التواصل الاجتماعي',
        'kamar_hkombat_social_settings_callback',
        'kamar_hkombat_theme_options'
    );
    
    $social_fields = array(
        'facebook_url'  => 'رابط فيسبوك',
        'twitter_url'   => 'رابط تويتر',
        'instagram_url' => 'رابط إنستغرام',
        'linkedin_url'  => 'رابط لينكدإن',
    );
    
    foreach ($social_fields as $field => $label) {
        add_settings_field(
            $field,
            $label,
            'kamar_hkombat_url_field_callback',
            'kamar_hkombat_theme_options',
            'kamar_hkombat_social_settings',
            array('field' => $field)
        );
    }
}
add_action('admin_init', 'kamar_hkombat_theme_options_init');

// رد اتصال قسم الإعدادات العامة
function kamar_hkombat_general_settings_callback() {
    echo '<p>الإعدادات العامة للقالب</p>';
}

// رد اتصال قسم وسائل التواصل الاجتماعي
function kamar_hkombat_social_settings_callback() {
    echo '<p>روابط وسائل التواصل الاجتماعي</p>';
}

// رد اتصال حقل النص
function kamar_hkombat_text_field_callback($args) {
    $options = get_option('kamar_hkombat_theme_options', kamar_hkombat_get_default_theme_options());
    $field = $args['field'];
    $value = isset($options[$field]) ? $options[$field] : '';
    
    echo '<input type="text" name="kamar_hkombat_theme_options[' . $field . ']" value="' . esc_attr($value) . '" class="regular-text">';
}

// رد اتصال حقل البريد الإلكتروني
function kamar_hkombat_email_field_callback($args) {
    $options = get_option('kamar_hkombat_theme_options', kamar_hkombat_get_default_theme_options());
    $field = $args['field'];
    $value = isset($options[$field]) ? $options[$field] : '';
    
    echo '<input type="email" name="kamar_hkombat_theme_options[' . $field . ']" value="' . esc_attr($value) . '" class="regular-text">';
}

// رد اتصال حقل textarea
function kamar_hkombat_textarea_field_callback($args) {
    $options = get_option('kamar_hkombat_theme_options', kamar_hkombat_get_default_theme_options());
    $field = $args['field'];
    $value = isset($options[$field]) ? $options[$field] : '';
    
    echo '<textarea name="kamar_hkombat_theme_options[' . $field . ']" rows="3" class="large-text">' . esc_textarea($value) . '</textarea>';
}

// رد اتصال حقل URL
function kamar_hkombat_url_field_callback($args) {
    $options = get_option('kamar_hkombat_theme_options', kamar_hkombat_get_default_theme_options());
    $field = $args['field'];
    $value = isset($options[$field]) ? $options[$field] : '';
    
    echo '<input type="url" name="kamar_hkombat_theme_options[' . $field . ']" value="' . esc_url($value) . '" class="regular-text">';
}

// إضافة صفحة الخيارات للقالب
function kamar_hkombat_add_theme_options_page() {
    add_theme_page(
        'خيارات القالب',
        'خيارات القالب',
        'manage_options',
        'kamar-hkombat-options',
        'kamar_hkombat_theme_options_page'
    );
}
add_action('admin_menu', 'kamar_hkombat_add_theme_options_page');

// عرض صفحة الخيارات
function kamar_hkombat_theme_options_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <?php settings_errors(); ?>
        
        <form method="post" action="options.php">
            <?php
            settings_fields('kamar_hkombat_theme_options');
            do_settings_sections('kamar_hkombat_theme_options');
            submit_button('حفظ التغييرات');
            ?>
        </form>
    </div>
    <?php
}