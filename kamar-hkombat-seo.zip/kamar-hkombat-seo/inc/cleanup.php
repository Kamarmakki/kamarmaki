<?php
/**
 * تنظيف رأس الصفحة
 */

// إزالة الروابط غير الضرورية من رأس الصفحة
function kamar_hkombat_clean_head() {
    remove_action('wp_head', 'feed_links_extra', 3);
    remove_action('wp_head', 'feed_links', 2);
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'index_rel_link');
    remove_action('wp_head', 'parent_post_rel_link', 10, 0);
    remove_action('wp_head', 'start_post_rel_link', 10, 0);
    remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0);
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'wp_shortlink_wp_head');
    remove_action('wp_head', 'rest_output_link_wp_head');
}
add_action('init', 'kamar_hkombat_clean_head');

// إزالة شريط الأدوات للجميع ما عدا المشرفين
function kamar_hkombat_remove_admin_bar() {
    if (!current_user_can('administrator') && !is_admin()) {
        show_admin_bar(false);
    }
}
add_action('after_setup_theme', 'kamar_hkombat_remove_admin_bar');

// إزالة فئات الصور غير المستخدمة
function kamar_hkombat_remove_unused_image_sizes($sizes) {
    unset($sizes['medium_large']);
    unset($sizes['1536x1536']);
    unset($sizes['2048x2048']);
    return $sizes;
}
add_filter('intermediate_image_sizes_advanced', 'kamar_hkombat_remove_unused_image_sizes');

// تحسين استعلامات قاعدة البيانات
function kamar_hkombat_optimize_database_queries($query) {
    if (!is_admin() && $query->is_main_query()) {
        // تحسين استعلامات الصفحة الرئيسية
        if ($query->is_home()) {
            $query->set('posts_per_page', 6);
        }
    }
}
add_action('pre_get_posts', 'kamar_hkombat_optimize_database_queries');