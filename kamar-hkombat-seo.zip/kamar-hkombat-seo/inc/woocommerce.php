<?php
/**
 * دعم WooCommerce
 */

// تفعيل دعم WooCommerce
function kamar_hkombat_woocommerce_support() {
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
    add_theme_support('woocommerce', array(
        'thumbnail_image_width' => 400,
        'gallery_thumbnail_image_width' => 100,
        'single_image_width' => 600,
    ));
}
add_action('after_setup_theme', 'kamar_hkombat_woocommerce_support');

// إزالة الأنماط الافتراضية
add_filter('woocommerce_enqueue_styles', '__return_empty_array');

// تعطيل الـ WooCommerce breadcrumbs
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);

// تغيير عدد المنتجات المعروضة في كل صفحة
add_filter('loop_shop_per_page', function($cols) {
    return 12;
});

// تغيير عدد الأعمدة في صفحة المتجر
add_filter('loop_shop_columns', 'kamar_hkombat_loop_columns');
function kamar_hkombat_loop_columns() {
    return 4;
}

// تغيير موضع الصور المصغرة
remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
add_action('woocommerce_before_shop_loop_item_title', 'kamar_hkombat_product_thumbnail', 10);

function kamar_hkombat_product_thumbnail() {
    echo '<div class="product-image-wrapper">';
    woocommerce_template_loop_product_thumbnail();
    echo '</div>';
}

// إضافة أزرار مخصصة
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
add_action('woocommerce_after_shop_loop_item', 'kamar_hkombat_add_to_cart_button', 10);

function kamar_hkombat_add_to_cart_button() {
    global $product;
    
    echo '<div class="product-buttons">';
    echo '<a href="' . get_permalink() . '" class="view-product">عرض التفاصيل</a>';
    
    if ($product->is_type('simple')) {
        woocommerce_template_loop_add_to_cart();
    }
    
    echo '</div>';
}

// تخصيص صفحة المنتج
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 10);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50);

add_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
add_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 10);
add_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
add_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30);
add_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);