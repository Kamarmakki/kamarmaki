<?php
/**
 * القيم الافتراضية للقالب
 */

// القيم الافتراضية للمخصص
function kamar_hkombat_get_default_theme_options() {
    return array(
        'primary_color'    => '#1a237e',
        'secondary_color'  => '#d4af37',
        'logo_text'        => 'Kamar Hkombat SEO',
        'phone_number'     => '+966 50 123 4567',
        'email_address'    => 'info@kamar.hkombat.com',
        'address'          => 'الرياض، المملكة العربية السعودية',
        'working_hours'    => 'السبت - الخميس: 9 ص - 6 م',
        'facebook_url'     => 'https://facebook.com',
        'twitter_url'      => 'https://twitter.com',
        'instagram_url'    => 'https://instagram.com',
        'linkedin_url'     => 'https://linkedin.com',
    );
}

// الحصول على قيمة خيار القالب
function kamar_hkombat_get_theme_option($key, $default = '') {
    $options = get_option('kamar_hkombat_theme_options', kamar_hkombat_get_default_theme_options());
    return isset($options[$key]) ? $options[$key] : $default;
}