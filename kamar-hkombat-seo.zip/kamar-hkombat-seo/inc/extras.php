<?php
/**
 * Extra functions for the theme
 *
 * @package Kamar_Hkombat
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

/**
 * Get theme option
 */
function kamar_hkombat_get_option($option, $default = '') {
    return get_theme_mod($option, $default);
}

/**
 * Get post views
 */
function kamar_hkombat_get_post_views($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    
    if ($count == '') {
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 View";
    }
    
    return $count . ' Views';
}

/**
 * Set post views
 */
function kamar_hkombat_set_post_views($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    
    if ($count == '') {
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    } else {
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

/**
 * Related posts
 */
function kamar_hkombat_related_posts($post_id, $related_count = 3) {
    $categories = get_the_category($post_id);
    
    if ($categories) {
        $category_ids = array();
        foreach ($categories as $category) {
            $category_ids[] = $category->term_id;
        }
        
        $args = array(
            'category__in' => $category_ids,
            'post__not_in' => array($post_id),
            'posts_per_page' => $related_count,
            'ignore_sticky_posts' => 1
        );
        
        $related_query = new WP_Query($args);
        
        if ($related_query->have_posts()) {
            echo '<div class="related-posts">';
            echo '<h3>' . __('Related Posts', 'kamar-hkombat') . '</h3>';
            echo '<div class="grid-3">';
            
            while ($related_query->have_posts()) {
                $related_query->the_post();
                get_template_part('template-parts/content', 'related');
            }
            
            echo '</div>';
            echo '</div>';
        }
        
        wp_reset_postdata();
    }
}

/**
 * Social links
 */
function kamar_hkombat_social_links() {
    $social_links = array(
        'facebook' => kamar_hkombat_get_option('facebook_url'),
        'twitter' => kamar_hkombat_get_option('twitter_url'),
        'instagram' => kamar_hkombat_get_option('instagram_url'),
        'linkedin' => kamar_hkombat_get_option('linkedin_url'),
        'youtube' => kamar_hkombat_get_option('youtube_url'),
    );
    
    echo '<div class="social-links">';
    
    foreach ($social_links as $platform => $url) {
        if (!empty($url)) {
            echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer">';
            echo '<i class="fab fa-' . esc_attr($platform) . '"></i>';
            echo '</a>';
        }
    }
    
    echo '</div>';
}

/**
 * Custom excerpt
 */
function kamar_hkombat_custom_excerpt($length = 20) {
    $excerpt = get_the_content();
    $excerpt = strip_tags($excerpt);
    $excerpt = substr($excerpt, 0, $length);
    $excerpt = substr($excerpt, 0, strripos($excerpt, " "));
    $excerpt .= '...';
    return $excerpt;
}

/**
 * Reading time
 */
function kamar_hkombat_reading_time() {
    $content = get_post_field('post_content', get_the_ID());
    $word_count = str_word_count(strip_tags($content));
    $readingtime = ceil($word_count / 200);
    
    if ($readingtime == 1) {
        $timer = " min read";
    } else {
        $timer = " mins read";
    }
    
    return $readingtime . $timer;
}

/**
 * Get first image from post content
 */
function kamar_hkombat_get_first_image() {
    global $post, $posts;
    $first_img = '';
    ob_start();
    ob_end_clean();
    $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
    $first_img = $matches[1][0];
    
    if (empty($first_img)) {
        $first_img = get_template_directory_uri() . '/images/default-thumbnail.jpg';
    }
    
    return $first_img;
}

/**
 * Custom pagination
 */
function kamar_hkombat_pagination($pages = '', $range = 2) {
    $showitems = ($range * 2) + 1;
    
    global $paged;
    if (empty($paged)) {
        $paged = 1;
    }
    
    if ($pages == '') {
        global $wp_query;
        $pages = $wp_query->max_num_pages;
        
        if (!$pages) {
            $pages = 1;
        }
    }
    
    if (1 != $pages) {
        echo "<div class='pagination'>";
        
        if ($paged > 2 && $paged > $range + 1 && $showitems < $pages) {
            echo "<a href='" . get_pagenum_link(1) . "'>&laquo;</a>";
        }
        
        if ($paged > 1 && $showitems < $pages) {
            echo "<a href='" . get_pagenum_link($paged - 1) . "'>&lsaquo;</a>";
        }
        
        for ($i = 1; $i <= $pages; $i++) {
            if (1 != $pages && (!($i >= $paged + $range + 1 || $i <= $paged - $range - 1) || $pages <= $showitems)) {
                echo ($paged == $i) ? "<span class='current'>" . $i . "</span>" : "<a href='" . get_pagenum_link($i) . "' class='inactive' >" . $i . "</a>";
            }
        }
        
        if ($paged < $pages && $showitems < $pages) {
            echo "<a href='" . get_pagenum_link($paged + 1) . "'>&rsaquo;</a>";
        }
        
        if ($paged < $pages - 1 && $paged + $range - 1 < $pages && $showitems < $pages) {
            echo "<a href='" . get_pagenum_link($pages) . "'>&raquo;</a>";
        }
        
        echo "</div>\n";
    }
}

/**
 * Breadcrumb
 */
function kamar_hkombat_breadcrumb() {
    if (!is_home() || !is_front_page()) {
        echo '<nav class="breadcrumb">';
        echo '<a href="' . home_url() . '">' . __('Home', 'kamar-hkombat') . '</a>';
        
        if (is_category() || is_single()) {
            echo " &raquo; ";
            the_category(' &raquo; ');
            
            if (is_single()) {
                echo " &raquo; ";
                the_title();
            }
        } elseif (is_page()) {
            echo " &raquo; ";
            the_title();
        } elseif (is_search()) {
            echo " &raquo; " . __('Search Results for ', 'kamar-hkombat') . '"' . get_search_query() . '"';
        } elseif (is_404()) {
            echo " &raquo; " . __('404 Not Found', 'kamar-hkombat');
        }
        
        echo '</nav>';
    }
}

/**
 * Custom comment callback
 */
function kamar_hkombat_comment($comment, $args, $depth) {
    if ('div' === $args['style']) {
        $tag = 'div';
        $add_below = 'comment';
    } else {
        $tag = 'li';
        $add_below = 'div-comment';
    }
    ?>
    <<?php echo $tag; ?> <?php comment_class(empty($args['has_children']) ? '' : 'parent'); ?> id="comment-<?php comment_ID(); ?>">
    <?php if ('div' != $args['style']) : ?>
        <div id="div-comment-<?php comment_ID(); ?>" class="comment-body">
    <?php endif; ?>
    <div class="comment-author vcard">
        <?php if (0 != $args['avatar_size']) {
            echo get_avatar($comment, $args['avatar_size']);
        } ?>
        <?php printf(__('<cite class="fn">%s</cite> <span class="says">says:</span>'), get_comment_author_link()); ?>
    </div>
    <?php if ('0' == $comment->comment_approved) : ?>
        <em class="comment-awaiting-moderation"><?php _e('Your comment is awaiting moderation.'); ?></em>
        <br />
    <?php endif; ?>
    <div class="comment-meta commentmetadata">
        <a href="<?php echo htmlspecialchars(get_comment_link($comment->comment_ID)); ?>">
            <?php
            /* translators: 1: date, 2: time */
            printf(__('%1$s at %2$s'), get_comment_date(), get_comment_time()); ?>
        </a>
        <?php edit_comment_link(__('(Edit)', '  ', ''); ?>
    </div>
    <?php comment_text(); ?>
    <div class="reply">
        <?php
        comment_reply_link(
            array_merge(
                $args,
                array(
                    'add_below' => $add_below,
                    'depth' => $depth,
                    'max_depth' => $args['max_depth'],
                )
            )
        );
        ?>
    </div>
    <?php if ('div' != $args['style']) : ?>
        </div>
    <?php endif; ?>
    <?php
}