<?php
/**
 * الصفحة الرئيسية
 */
get_header(); ?>

<!-- Hero Section -->
<section class="hero">
    <div class="container">
        <div class="hero-content text-center">
            <h1>أول منصة عربية متكاملة لخدمات السيو</h1>
            <p>حقّق أعلى تصنيف في جوجل مع خدمات تحسين محركات البحث الاحترافية</p>
            <div class="hero-buttons">
                <a href="#contact" class="btn btn-primary">ابدأ الآن</a>
                <a href="#services" class="btn btn-secondary">تعرف على خدماتنا</a>
            </div>
        </div>
    </div>
</section>

<?php 
get_template_part('template-parts/content', 'services');
get_template_part('template-parts/content', 'tools');
get_template_part('template-parts/content', 'pricing');
get_template_part('template-parts/content', 'faq');
get_template_part('template-parts/content', 'contact');
get_footer();