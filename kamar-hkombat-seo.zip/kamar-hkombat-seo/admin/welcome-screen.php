<?php
/**
 * Welcome Screen for Kamar Hkombat SEO Theme
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class Kamar_Hkombat_SEO_Welcome_Screen {
    
    private $theme;
    
    public function __construct() {
        $this->theme = wp_get_theme();
        
        add_action('admin_menu', array($this, 'add_welcome_page'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('after_switch_theme', array($this, 'activation_redirect'));
    }
    
    public function add_welcome_page() {
        add_theme_page(
            'Welcome to Kamar Hkombat SEO Theme',
            'Welcome',
            'manage_options',
            'kamar-hkombat-seo-welcome',
            array($this, 'render_welcome_screen')
        );
    }
    
    public function enqueue_styles($hook) {
        if ('appearance_page_kamar-hkombat-seo-welcome' === $hook) {
            wp_enqueue_style('kamar-hkombat-seo-welcome', get_template_directory_uri() . '/admin/css/welcome-screen.css', array(), $this->theme->get('Version'));
        }
    }
    
    public function activation_redirect() {
        if (current_user_can('edit_theme_options')) {
            header('Location:' . admin_url('themes.php?page=kamar-hkombat-seo-welcome'));
            exit;
        }
    }
    
    public function render_welcome_screen() {
        ?>
        <div class="wrap about-wrap kamar-hkombat-seo-welcome">
            <h1><?php printf('Welcome to %s!', $this->theme->get('Name')); ?></h1>
            
            <div class="about-text">
                Thank you for using Kamar Hkombat SEO Theme - The first comprehensive Arabic platform for SEO services. This theme is specifically designed for SEO service and search engine optimization websites.
            </div>
            
            <div class="wp-badge"><?php printf('Version %s', $this->theme->get('Version')); ?></div>
            
            <h2 class="nav-tab-wrapper">
                <a href="#getting-started" class="nav-tab nav-tab-active">Getting Started</a>
                <a href="#recommended-plugins" class="nav-tab">Recommended Plugins</a>
                <a href="#documentation" class="nav-tab">Documentation</a>
                <a href="#support" class="nav-tab">Support</a>
            </h2>
            
            <div id="getting-started" class="tab-content active">
                <div class="feature-section">
                    <h2>Getting Started with the Theme</h2>
                    
                    <div class="feature-section-items">
                        <div class="feature-section-item">
                            <h3>1. Install Required Plugins</h3>
                            <p>Make sure to install and activate the essential plugins for the theme to work properly.</p>
                            <a href="#recommended-plugins" class="button button-primary">View Plugins</a>
                        </div>
                        
                        <div class="feature-section-item">
                            <h3>2. Theme Setup</h3>
                            <p>Configure the basic theme settings from the control panel.</p>
                            <a href="<?php echo admin_url('admin.php?page=kamar_hkombat_seo_options'); ?>" class="button button-primary">Theme Settings</a>
                        </div>
                        
                        <div class="feature-section-item">
                            <h3>3. Import Demo Content</h3>
                            <p>Import demo content to get a look similar to the original site.</p>
                            <a href="#" class="button button-primary">Import Content</a>
                        </div>
                    </div>
                </div>
                
                <div class="feature-section">
                    <h2>Key Features</h2>
                    
                    <div class="feature-section-items">
                        <div class="feature-section-item">
                            <h3>Responsive Design</h3>
                            <p>Works perfectly on all devices and screens.</p>
                        </div>
                        
                        <div class="feature-section-item">
                            <h3>SEO Optimized</h3>
                            <p>Built with best SEO practices for search engines.</p>
                        </div>
                        
                        <div class="feature-section-item">
                            <h3>Fast and Lightweight</h3>
                            <p>Optimized for speed and high performance.</p>
                        </div>
                        
                        <div class="feature-section-item">
                            <h3>Easy to Customize</h3>
                            <p>Easy interface for customization and settings.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="recommended-plugins" class="tab-content">
                <div class="feature-section">
                    <h2>Recommended Plugins</h2>
                    
                    <div class="recommended-plugins">
                        <div class="plugin-card">
                            <h3>Elementor</h3>
                            <p>The most powerful visual page builder.</p>
                            <a href="<?php echo admin_url('plugin-install.php?tab=search&s=elementor'); ?>" class="button button-primary">Install</a>
                        </div>
                        
                        <div class="plugin-card">
                            <h3>Contact Form 7</h3>
                            <p>Create contact forms easily.</p>
                            <a href="<?php echo admin_url('plugin-install.php?tab=search&s=contact+form+7'); ?>" class="button button-primary">Install</a>
                        </div>
                        
                        <div class="plugin-card">
                            <h3>Yoast SEO</h3>
                            <p>The best plugin for SEO optimization.</p>
                            <a href="<?php echo admin_url('plugin-install.php?tab=search&s=yoast+seo'); ?>" class="button button-primary">Install</a>
                        </div>
                        
                        <div class="plugin-card">
                            <h3>W3 Total Cache</h3>
                            <p>For improving website speed.</p>
                            <a href="<?php echo admin_url('plugin-install.php?tab=search&s=w3+total+cache'); ?>" class="button button-primary">Install</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="documentation" class="tab-content">
                <div class="feature-section">
                    <h2>User Guide</h2>
                    
                    <div class="documentation-sections">
                        <div class="doc-section">
                            <h3>Basic Theme Setup</h3>
                            <p>Learn how to set up the basic theme and general settings.</p>
                            <a href="#" class="button button-secondary">Read More</a>
                        </div>
                        
                        <div class="doc-section">
                            <h3>Creating Services</h3>
                            <p>How to create and manage service pages.</p>
                            <a href="#" class="button button-secondary">Read More</a>
                        </div>
                        
                        <div class="doc-section">
                            <h3>Managing Packages</h3>
                            <p>Create and customize pricing packages.</p>
                            <a href="#" class="button button-secondary">Read More</a>
                        </div>
                        
                        <div class="doc-section">
                            <h3>Advanced Customization</h3>
                            <p>Advanced theme customization, colors, and fonts.</p>
                            <a href="#" class="button button-secondary">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="support" class="tab-content">
                <div class="feature-section">
                    <h2>Technical Support</h2>
                    
                    <div class="support-options">
                        <div class="support-option">
                            <h3>Documentation</h3>
                            <p>Read the complete user guide for the theme.</p>
                            <a href="#" class="button button-secondary">View Guide</a>
                        </div>
                        
                        <div class="support-option">
                            <h3>FAQ</h3>
                            <p>Find answers to frequently asked questions.</p>
                            <a href="#" class="button button-secondary">FAQ</a>
                        </div>
                        
                        <div class="support-option">
                            <h3>Email Support</h3>
                            <p>Contact us via email.</p>
                            <a href="mailto:support@kamarmakki.com" class="button button-secondary">Contact</a>
                        </div>
                        
                        <div class="support-option">
                            <h3>Updates</h3>
                            <p>Get the latest theme updates.</p>
                            <a href="#" class="button button-secondary">Updates</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="return-to-dashboard">
                <a href="<?php echo admin_url('index.php'); ?>"><?php _e('Go to Dashboard &rarr; Home'); ?></a>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('.nav-tab-wrapper .nav-tab').click(function(e) {
                e.preventDefault();
                
                $('.nav-tab-wrapper .nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                $('.tab-content').removeClass('active');
                $($(this).attr('href')).addClass('active');
            });
        });
        </script>
        <?php
    }
}

// Initialize the welcome screen
$kamar_hkombat_seo_welcome_screen = new Kamar_Hkombat_SEO_Welcome_Screen();