<?php
/**
 * Theme Options for Kamar Hkombat SEO
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class Kamar_Hkombat_SEO_Theme_Options {
    
    private $options;
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_theme_options_page'));
        add_action('admin_init', array($this, 'page_init'));
    }
    
    public function add_theme_options_page() {
        add_menu_page(
            'Kamar Hkombat SEO Theme Settings', 
            'Theme Settings', 
            'manage_options', 
            'kamar_hkombat_seo_options', 
            array($this, 'create_theme_options_page'),
            'dashicons-admin-generic',
            60
        );
    }
    
    public function create_theme_options_page() {
        $this->options = get_option('kamar_hkombat_seo_options');
        ?>
        <div class="wrap">
            <h1>Kamar Hkombat SEO Theme Settings</h1>
            <form method="post" action="options.php">
            <?php
                settings_fields('kamar_hkombat_seo_option_group');
                do_settings_sections('kamar_hkombat_seo_options');
                submit_button();
            ?>
            </form>
        </div>
        <?php
    }
    
    public function page_init() {
        register_setting(
            'kamar_hkombat_seo_option_group',
            'kamar_hkombat_seo_options',
            array($this, 'sanitize')
        );
        
        // General Settings Section
        add_settings_section(
            'general_settings',
            'General Settings',
            array($this, 'general_settings_info'),
            'kamar_hkombat_seo_options'
        );
        
        // Contact Settings Section
        add_settings_section(
            'contact_settings',
            'Contact Information',
            array($this, 'contact_settings_info'),
            'kamar_hkombat_seo_options'
        );
        
        // Social Media Settings Section
        add_settings_section(
            'social_settings',
            'Social Media',
            array($this, 'social_settings_info'),
            'kamar_hkombat_seo_options'
        );
        
        // SEO Settings Section
        add_settings_section(
            'seo_settings',
            'SEO Settings',
            array($this, 'seo_settings_info'),
            'kamar_hkombat_seo_options'
        );
        
        // Add fields
        $this->add_general_fields();
        $this->add_contact_fields();
        $this->add_social_fields();
        $this->add_seo_fields();
    }
    
    public function sanitize($input) {
        $new_input = array();
        
        // General fields
        if(isset($input['site_logo']))
            $new_input['site_logo'] = sanitize_text_field($input['site_logo']);
            
        if(isset($input['favicon']))
            $new_input['favicon'] = sanitize_text_field($input['favicon']);
            
        // Contact fields
        if(isset($input['phone']))
            $new_input['phone'] = sanitize_text_field($input['phone']);
            
        if(isset($input['email']))
            $new_input['email'] = sanitize_email($input['email']);
            
        if(isset($input['address']))
            $new_input['address'] = sanitize_textarea_field($input['address']);
            
        // Social fields
        if(isset($input['facebook']))
            $new_input['facebook'] = esc_url_raw($input['facebook']);
            
        if(isset($input['twitter']))
            $new_input['twitter'] = esc_url_raw($input['twitter']);
            
        if(isset($input['instagram']))
            $new_input['instagram'] = esc_url_raw($input['instagram']);
            
        if(isset($input['linkedin']))
            $new_input['linkedin'] = esc_url_raw($input['linkedin']);
            
        // SEO fields
        if(isset($input['google_analytics']))
            $new_input['google_analytics'] = sanitize_textarea_field($input['google_analytics']);
            
        if(isset($input['google_site_verification']))
            $new_input['google_site_verification'] = sanitize_text_field($input['google_site_verification']);
            
        return $new_input;
    }
    
    public function general_settings_info() {
        print 'General website settings';
    }
    
    public function contact_settings_info() {
        print 'Website contact information';
    }
    
    public function social_settings_info() {
        print 'Social media links';
    }
    
    public function seo_settings_info() {
        print 'SEO and tracking settings';
    }
    
    private function add_general_fields() {
        add_settings_field(
            'site_logo',
            'Site Logo',
            array($this, 'site_logo_callback'),
            'kamar_hkombat_seo_options',
            'general_settings'
        );
        
        add_settings_field(
            'favicon',
            'Site Favicon',
            array($this, 'favicon_callback'),
            'kamar_hkombat_seo_options',
            'general_settings'
        );
    }
    
    private function add_contact_fields() {
        add_settings_field(
            'phone',
            'Phone Number',
            array($this, 'phone_callback'),
            'kamar_hkombat_seo_options',
            'contact_settings'
        );
        
        add_settings_field(
            'email',
            'Email Address',
            array($this, 'email_callback'),
            'kamar_hkombat_seo_options',
            'contact_settings'
        );
        
        add_settings_field(
            'address',
            'Address',
            array($this, 'address_callback'),
            'kamar_hkombat_seo_options',
            'contact_settings'
        );
    }
    
    private function add_social_fields() {
        add_settings_field(
            'facebook',
            'Facebook',
            array($this, 'facebook_callback'),
            'kamar_hkombat_seo_options',
            'social_settings'
        );
        
        add_settings_field(
            'twitter',
            'Twitter',
            array($this, 'twitter_callback'),
            'kamar_hkombat_seo_options',
            'social_settings'
        );
        
        add_settings_field(
            'instagram',
            'Instagram',
            array($this, 'instagram_callback'),
            'kamar_hkombat_seo_options',
            'social_settings'
        );
        
        add_settings_field(
            'linkedin',
            'LinkedIn',
            array($this, 'linkedin_callback'),
            'kamar_hkombat_seo_options',
            'social_settings'
        );
    }
    
    private function add_seo_fields() {
        add_settings_field(
            'google_analytics',
            'Google Analytics Code',
            array($this, 'google_analytics_callback'),
            'kamar_hkombat_seo_options',
            'seo_settings'
        );
        
        add_settings_field(
            'google_site_verification',
            'Google Verification Code',
            array($this, 'google_site_verification_callback'),
            'kamar_hkombat_seo_options',
            'seo_settings'
        );
    }
    
    // Callback functions
    public function site_logo_callback() {
        printf(
            '<input type="text" id="site_logo" name="kamar_hkombat_seo_options[site_logo]" value="%s" class="regular-text" />
             <button type="button" class="button button-secondary upload-logo-button">Upload Logo</button>',
            isset($this->options['site_logo']) ? esc_attr($this->options['site_logo']) : ''
        );
    }
    
    public function favicon_callback() {
        printf(
            '<input type="text" id="favicon" name="kamar_hkombat_seo_options[favicon]" value="%s" class="regular-text" />
             <button type="button" class="button button-secondary upload-favicon-button">Upload Favicon</button>',
            isset($this->options['favicon']) ? esc_attr($this->options['favicon']) : ''
        );
    }
    
    public function phone_callback() {
        printf(
            '<input type="text" id="phone" name="kamar_hkombat_seo_options[phone]" value="%s" class="regular-text" />',
            isset($this->options['phone']) ? esc_attr($this->options['phone']) : ''
        );
    }
    
    public function email_callback() {
        printf(
            '<input type="email" id="email" name="kamar_hkombat_seo_options[email]" value="%s" class="regular-text" />',
            isset($this->options['email']) ? esc_attr($this->options['email']) : ''
        );
    }
    
    public function address_callback() {
        printf(
            '<textarea id="address" name="kamar_hkombat_seo_options[address]" rows="3" class="large-text">%s</textarea>',
            isset($this->options['address']) ? esc_textarea($this->options['address']) : ''
        );
    }
    
    public function facebook_callback() {
        printf(
            '<input type="url" id="facebook" name="kamar_hkombat_seo_options[facebook]" value="%s" class="regular-text" />',
            isset($this->options['facebook']) ? esc_attr($this->options['facebook']) : ''
        );
    }
    
    public function twitter_callback() {
        printf(
            '<input type="url" id="twitter" name="kamar_hkombat_seo_options[twitter]" value="%s" class="regular-text" />',
            isset($this->options['twitter']) ? esc_attr($this->options['twitter']) : ''
        );
    }
    
    public function instagram_callback() {
        printf(
            '<input type="url" id="instagram" name="kamar_hkombat_seo_options[instagram]" value="%s" class="regular-text" />',
            isset($this->options['instagram']) ? esc_attr($this->options['instagram']) : ''
        );
    }
    
    public function linkedin_callback() {
        printf(
            '<input type="url" id="linkedin" name="kamar_hkombat_seo_options[linkedin]" value="%s" class="regular-text" />',
            isset($this->options['linkedin']) ? esc_attr($this->options['linkedin']) : ''
        );
    }
    
    public function google_analytics_callback() {
        printf(
            '<textarea id="google_analytics" name="kamar_hkombat_seo_options[google_analytics]" rows="5" class="large-text">%s</textarea>
             <p class="description">Enter Google Analytics code here</p>',
            isset($this->options['google_analytics']) ? esc_textarea($this->options['google_analytics']) : ''
        );
    }
    
    public function google_site_verification_callback() {
        printf(
            '<input type="text" id="google_site_verification" name="kamar_hkombat_seo_options[google_site_verification]" value="%s" class="regular-text" />
             <p class="description">Enter Google Search Console verification code here</p>',
            isset($this->options['google_site_verification']) ? esc_attr($this->options['google_site_verification']) : ''
        );
    }
}

// Initialize the theme options
if (is_admin()) {
    $kamar_hkombat_seo_theme_options = new Kamar_Hkombat_SEO_Theme_Options();
}