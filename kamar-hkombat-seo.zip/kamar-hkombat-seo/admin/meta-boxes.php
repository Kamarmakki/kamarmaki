<?php
/**
 * Custom Meta Boxes for Kamar Hkombat SEO Theme
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class Kamar_Hkombat_SEO_Meta_Boxes {
    
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_meta_boxes'));
    }
    
    public function add_meta_boxes() {
        // Service Meta Box
        add_meta_box(
            'service_details',
            'تفاصيل الخدمة',
            array($this, 'service_details_callback'),
            'service',
            'normal',
            'high'
        );
        
        // Pricing Meta Box
        add_meta_box(
            'pricing_details',
            'تفاصيل الباقة',
            array($this, 'pricing_details_callback'),
            'pricing',
            'normal',
            'high'
        );
        
        // Testimonial Meta Box
        add_meta_box(
            'testimonial_details',
            'تفاصيل التقييم',
            array($this, 'testimonial_details_callback'),
            'testimonial',
            'normal',
            'high'
        );
        
        // SEO Meta Box (for all post types)
        add_meta_box(
            'seo_meta',
            'إعدادات السيو',
            array($this, 'seo_meta_callback'),
            array('post', 'page', 'service', 'pricing'),
            'normal',
            'high'
        );
    }
    
    public function service_details_callback($post) {
        wp_nonce_field('service_details_nonce', 'service_details_nonce_field');
        
        $service_price = get_post_meta($post->ID, '_service_price', true);
        $service_duration = get_post_meta($post->ID, '_service_duration', true);
        $service_features = get_post_meta($post->ID, '_service_features', true);
        $service_icon = get_post_meta($post->ID, '_service_icon', true);
        $service_button_text = get_post_meta($post->ID, '_service_button_text', true);
        $service_button_url = get_post_meta($post->ID, '_service_button_url', true);
        ?>
        <div class="meta-box-field">
            <label for="service_price">السعر:</label>
            <input type="text" id="service_price" name="service_price" value="<?php echo esc_attr($service_price); ?>" class="regular-text" />
        </div>
        
        <div class="meta-box-field">
            <label for="service_duration">المدة:</label>
            <input type="text" id="service_duration" name="service_duration" value="<?php echo esc_attr($service_duration); ?>" class="regular-text" />
        </div>
        
        <div class="meta-box-field">
            <label for="service_features">المميزات (واحد في كل سطر):</label>
            <textarea id="service_features" name="service_features" rows="5" class="large-text"><?php echo esc_textarea($service_features); ?></textarea>
        </div>
        
        <div class="meta-box-field">
            <label for="service_icon">الأيقونة (Font Awesome class):</label>
            <input type="text" id="service_icon" name="service_icon" value="<?php echo esc_attr($service_icon); ?>" class="regular-text" />
            <p class="description">مثال: fas fa-search</p>
        </div>
        
        <div class="meta-box-field">
            <label for="service_button_text">نص الزر:</label>
            <input type="text" id="service_button_text" name="service_button_text" value="<?php echo esc_attr($service_button_text); ?>" class="regular-text" />
        </div>
        
        <div class="meta-box-field">
            <label for="service_button_url">رابط الزر:</label>
            <input type="url" id="service_button_url" name="service_button_url" value="<?php echo esc_attr($service_button_url); ?>" class="regular-text" />
        </div>
        <?php
    }
    
    public function pricing_details_callback($post) {
        wp_nonce_field('pricing_details_nonce', 'pricing_details_nonce_field');
        
        $pricing_price = get_post_meta($post->ID, '_pricing_price', true);
        $pricing_period = get_post_meta($post->ID, '_pricing_period', true);
        $pricing_features = get_post_meta($post->ID, '_pricing_features', true);
        $pricing_featured = get_post_meta($post->ID, '_pricing_featured', true);
        $pricing_button_text = get_post_meta($post->ID, '_pricing_button_text', true);
        $pricing_button_url = get_post_meta($post->ID, '_pricing_button_url', true);
        ?>
        <div class="meta-box-field">
            <label for="pricing_price">السعر:</label>
            <input type="text" id="pricing_price" name="pricing_price" value="<?php echo esc_attr($pricing_price); ?>" class="regular-text" />
        </div>
        
        <div class="meta-box-field">
            <label for="pricing_period">الفترة:</label>
            <input type="text" id="pricing_period" name="pricing_period" value="<?php echo esc_attr($pricing_period); ?>" class="regular-text" />
            <p class="description">مثال: شهرياً، سنوياً</p>
        </div>
        
        <div class="meta-box-field">
            <label for="pricing_features">المميزات (واحد في كل سطر):</label>
            <textarea id="pricing_features" name="pricing_features" rows="8" class="large-text"><?php echo esc_textarea($pricing_features); ?></textarea>
        </div>
        
        <div class="meta-box-field">
            <label for="pricing_featured">
                <input type="checkbox" id="pricing_featured" name="pricing_featured" value="1" <?php checked($pricing_featured, '1'); ?> />
                باقة مميزة
            </label>
        </div>
        
        <div class="meta-box-field">
            <label for="pricing_button_text">نص الزر:</label>
            <input type="text" id="pricing_button_text" name="pricing_button_text" value="<?php echo esc_attr($pricing_button_text); ?>" class="regular-text" />
        </div>
        
        <div class="meta-box-field">
            <label for="pricing_button_url">رابط الزر:</label>
            <input type="url" id="pricing_button_url" name="pricing_button_url" value="<?php echo esc_attr($pricing_button_url); ?>" class="regular-text" />
        </div>
        <?php
    }
    
    public function testimonial_details_callback($post) {
        wp_nonce_field('testimonial_details_nonce', 'testimonial_details_nonce_field');
        
        $testimonial_name = get_post_meta($post->ID, '_testimonial_name', true);
        $testimonial_position = get_post_meta($post->ID, '_testimonial_position', true);
        $testimonial_company = get_post_meta($post->ID, '_testimonial_company', true);
        $testimonial_rating = get_post_meta($post->ID, '_testimonial_rating', true);
        $testimonial_avatar = get_post_meta($post->ID, '_testimonial_avatar', true);
        ?>
        <div class="meta-box-field">
            <label for="testimonial_name">اسم العميل:</label>
            <input type="text" id="testimonial_name" name="testimonial_name" value="<?php echo esc_attr($testimonial_name); ?>" class="regular-text" />
        </div>
        
        <div class="meta-box-field">
            <label for="testimonial_position">المنصب:</label>
            <input type="text" id="testimonial_position" name="testimonial_position" value="<?php echo esc_attr($testimonial_position); ?>" class="regular-text" />
        </div>
        
        <div class="meta-box-field">
            <label for="testimonial_company">الشركة:</label>
            <input type="text" id="testimonial_company" name="testimonial_company" value="<?php echo esc_attr($testimonial_company); ?>" class="regular-text" />
        </div>
        
        <div class="meta-box-field">
            <label for="testimonial_rating">التقييم (1-5):</label>
            <select id="testimonial_rating" name="testimonial_rating">
                <option value="1" <?php selected($testimonial_rating, '1'); ?>>1</option>
                <option value="2" <?php selected($testimonial_rating, '2'); ?>>2</option>
                <option value="3" <?php selected($testimonial_rating, '3'); ?>>3</option>
                <option value="4" <?php selected($testimonial_rating, '4'); ?>>4</option>
                <option value="5" <?php selected($testimonial_rating, '5'); ?>>5</option>
            </select>
        </div>
        
        <div class="meta-box-field">
            <label for="testimonial_avatar">صورة العميل:</label>
            <input type="text" id="testimonial_avatar" name="testimonial_avatar" value="<?php echo esc_attr($testimonial_avatar); ?>" class="regular-text" />
            <button type="button" class="button button-secondary upload-avatar-button">رفع الصورة</button>
        </div>
        <?php
    }
    
    public function seo_meta_callback($post) {
        wp_nonce_field('seo_meta_nonce', 'seo_meta_nonce_field');
        
        $seo_title = get_post_meta($post->ID, '_seo_title', true);
        $seo_description = get_post_meta($post->ID, '_seo_description', true);
        $seo_keywords = get_post_meta($post->ID, '_seo_keywords', true);
        $seo_robots_index = get_post_meta($post->ID, '_seo_robots_index', true);
        $seo_canonical = get_post_meta($post->ID, '_seo_canonical', true);
        ?>
        <div class="meta-box-field">
            <label for="seo_title">عنوان SEO:</label>
            <input type="text" id="seo_title" name="seo_title" value="<?php echo esc_attr($seo_title); ?>" class="large-text" maxlength="60" />
            <p class="description">الأفضل: 60 حرف كحد أقصى</p>
        </div>
        
        <div class="meta-box-field">
            <label for="seo_description">وصف SEO:</label>
            <textarea id="seo_description" name="seo_description" rows="3" class="large-text" maxlength="160"><?php echo esc_textarea($seo_description); ?></textarea>
            <p class="description">الأفضل: 160 حرف كحد أقصى</p>
        </div>
        
        <div class="meta-box-field">
            <label for="seo_keywords">كلمات مفتاحية:</label>
            <input type="text" id="seo_keywords" name="seo_keywords" value="<?php echo esc_attr($seo_keywords); ?>" class="large-text" />
            <p class="description">افصل بين الكلمات بفاصلة (,)</p>
        </div>
        
        <div class="meta-box-field">
            <label for="seo_robots_index">
                <input type="checkbox" id="seo_robots_index" name="seo_robots_index" value="noindex" <?php checked($seo_robots_index, 'noindex'); ?> />
                منع الفهرسة (noindex)
            </label>
        </div>
        
        <div class="meta-box-field">
            <label for="seo_canonical">رابط Canonical:</label>
            <input type="url" id="seo_canonical" name="seo_canonical" value="<?php echo esc_attr($seo_canonical); ?>" class="large-text" />
        </div>
        <?php
    }
    
    public function save_meta_boxes($post_id) {
        // Check nonce for service details
        if (isset($_POST['service_details_nonce_field']) && !wp_verify_nonce($_POST['service_details_nonce_field'], 'service_details_nonce')) {
            return;
        }
        
        // Check nonce for pricing details
        if (isset($_POST['pricing_details_nonce_field']) && !wp_verify_nonce($_POST['pricing_details_nonce_field'], 'pricing_details_nonce')) {
            return;
        }
        
        // Check nonce for testimonial details
        if (isset($_POST['testimonial_details_nonce_field']) && !wp_verify_nonce($_POST['testimonial_details_nonce_field'], 'testimonial_details_nonce')) {
            return;
        }
        
        // Check nonce for SEO meta
        if (isset($_POST['seo_meta_nonce_field']) && !wp_verify_nonce($_POST['seo_meta_nonce_field'], 'seo_meta_nonce')) {
            return;
        }
        
        // Check user capabilities
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Save service details
        if (isset($_POST['service_price'])) {
            update_post_meta($post_id, '_service_price', sanitize_text_field($_POST['service_price']));
        }
        
        if (isset($_POST['service_duration'])) {
            update_post_meta($post_id, '_service_duration', sanitize_text_field($_POST['service_duration']));
        }
        
        if (isset($_POST['service_features'])) {
            update_post_meta($post_id, '_service_features', sanitize_textarea_field($_POST['service_features']));
        }
        
        if (isset($_POST['service_icon'])) {
            update_post_meta($post_id, '_service_icon', sanitize_text_field($_POST['service_icon']));
        }
        
        if (isset($_POST['service_button_text'])) {
            update_post_meta($post_id, '_service_button_text', sanitize_text_field($_POST['service_button_text']));
        }
        
        if (isset($_POST['service_button_url'])) {
            update_post_meta($post_id, '_service_button_url', esc_url_raw($_POST['service_button_url']));
        }
        
        // Save pricing details
        if (isset($_POST['pricing_price'])) {
            update_post_meta($post_id, '_pricing_price', sanitize_text_field($_POST['pricing_price']));
        }
        
        if (isset($_POST['pricing_period'])) {
            update_post_meta($post_id, '_pricing_period', sanitize_text_field($_POST['pricing_period']));
        }
        
        if (isset($_POST['pricing_features'])) {
            update_post_meta($post_id, '_pricing_features', sanitize_textarea_field($_POST['pricing_features']));
        }
        
        if (isset($_POST['pricing_featured'])) {
            update_post_meta($post_id, '_pricing_featured', '1');
        } else {
            update_post_meta($post_id, '_pricing_featured', '0');
        }
        
        if (isset($_POST['pricing_button_text'])) {
            update_post_meta($post_id, '_pricing_button_text', sanitize_text_field($_POST['pricing_button_text']));
        }
        
        if (isset($_POST['pricing_button_url'])) {
            update_post_meta($post_id, '_pricing_button_url', esc_url_raw($_POST['pricing_button_url']));
        }
        
        // Save testimonial details
        if (isset($_POST['testimonial_name'])) {
            update_post_meta($post_id, '_testimonial_name', sanitize_text_field($_POST['testimonial_name']));
        }
        
        if (isset($_POST['testimonial_position'])) {
            update_post_meta($post_id, '_testimonial_position', sanitize_text_field($_POST['testimonial_position']));
        }
        
        if (isset($_POST['testimonial_company'])) {
            update_post_meta($post_id, '_testimonial_company', sanitize_text_field($_POST['testimonial_company']));
        }
        
        if (isset($_POST['testimonial_rating'])) {
            update_post_meta($post_id, '_testimonial_rating', sanitize_text_field($_POST['testimonial_rating']));
        }
        
        if (isset($_POST['testimonial_avatar'])) {
            update_post_meta($post_id, '_testimonial_avatar', esc_url_raw($_POST['testimonial_avatar']));
        }
        
        // Save SEO meta
        if (isset($_POST['seo_title'])) {
            update_post_meta($post_id, '_seo_title', sanitize_text_field($_POST['seo_title']));
        }
        
        if (isset($_POST['seo_description'])) {
            update_post_meta($post_id, '_seo_description', sanitize_textarea_field($_POST['seo_description']));
        }
        
        if (isset($_POST['seo_keywords'])) {
            update_post_meta($post_id, '_seo_keywords', sanitize_text_field($_POST['seo_keywords']));
        }
        
        if (isset($_POST['seo_robots_index'])) {
            update_post_meta($post_id, '_seo_robots_index', sanitize_text_field($_POST['seo_robots_index']));
        } else {
            update_post_meta($post_id, '_seo_robots_index', '');
        }
        
        if (isset($_POST['seo_canonical'])) {
            update_post_meta($post_id, '_seo_canonical', esc_url_raw($_POST['seo_canonical']));
        }
    }
}

// Initialize the meta boxes
$kamar_hkombat_seo_meta_boxes = new Kamar_Hkombat_SEO_Meta_Boxes();