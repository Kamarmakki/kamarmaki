<?php
/**
 * قالب نتائج البحث
 */
get_header(); ?>

<div class="container section-padding">
    <header class="page-header">
        <h1 class="page-title">
            <?php printf(__('نتائج البحث عن: %s', 'kamar-hkombat'), '<span>' . get_search_query() . '</span>'); ?>
        </h1>
    </header>
    
    <div class="content-area">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <?php get_template_part('template-parts/content', 'post'); ?>
            <?php endwhile; ?>
            
            <?php the_posts_pagination([
                'prev_text' => 'السابق',
                'next_text' => 'التالي',
            ]); ?>
        <?php else : ?>
            <?php get_template_part('template-parts/content', 'none'); ?>
        <?php endif; ?>
    </div>
</div>

<?php get_footer();