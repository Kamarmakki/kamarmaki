<?php
/**
 * رأس القالب
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    
    <header>
        <div class="container header-container">
            <div class="mobile-menu-btn">
                <i class="fas fa-bars"></i>
            </div>
            <div class="logo">
                <?php if (has_custom_logo()) : the_custom_logo(); else : ?>
                    <i class="fas fa-chart-line"></i>
                    <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                <?php endif; ?>
            </div>
            <nav>
                <?php wp_nav_menu([
                    'theme_location' => 'primary',
                    'menu_class' => 'primary-menu',
                    'container' => false
                ]); ?>
            </nav>
        </div>
    </header>