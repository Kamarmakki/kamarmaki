(function($) {
    'use strict';

    // التحميل البطيء للصور
    function lazyLoadImages() {
        const lazyImages = document.querySelectorAll('img[data-src]');
        
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.removeAttribute('data-src');
                    img.classList.add('loaded');
                    observer.unobserve(img);
                }
            });
        });

        lazyImages.forEach(img => {
            imageObserver.observe(img);
        });
    }

    // التحميل البطيء للفيديوهات
    function lazyLoadVideos() {
        const lazyVideos = document.querySelectorAll('video[data-src]');
        
        const videoObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const video = entry.target;
                    video.src = video.dataset.src;
                    video.removeAttribute('data-src');
                    video.classList.add('loaded');
                    observer.unobserve(video);
                }
            });
        });

        lazyVideos.forEach(video => {
            videoObserver.observe(video);
        });
    }

    // التحميل البطيء لإطارات iframe
    function lazyLoadIframes() {
        const lazyIframes = document.querySelectorAll('iframe[data-src]');
        
        const iframeObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const iframe = entry.target;
                    iframe.src = iframe.dataset.src;
                    iframe.removeAttribute('data-src');
                    iframe.classList.add('loaded');
                    observer.unobserve(iframe);
                }
            });
        });

        lazyIframes.forEach(iframe => {
            iframeObserver.observe(iframe);
        });
    }

    // تهيئة التحميل البطيء
    document.addEventListener('DOMContentLoaded', function() {
        lazyLoadImages();
        lazyLoadVideos();
        lazyLoadIframes();
    });

    // إضافة تأثيرات عند تحميل الصور
    document.addEventListener('DOMContentLoaded', function() {
        const style = document.createElement('style');
        style.textContent = `
            img[data-src] {
                opacity: 0;
                transition: opacity 0.3s ease;
            }
            img.loaded {
                opacity: 1;
            }
            video[data-src], iframe[data-src] {
                opacity: 0;
                transition: opacity 0.3s ease;
            }
            video.loaded, iframe.loaded {
                opacity: 1;
            }
        `;
        document.head.appendChild(style);
    });

})(jQuery);