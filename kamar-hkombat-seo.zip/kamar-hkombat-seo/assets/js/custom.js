(function($) {
    'use strict';

    // Mobile Menu Toggle
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const nav = document.querySelector('nav');
    
    if (mobileMenuBtn && nav) {
        mobileMenuBtn.addEventListener('click', () => {
            nav.classList.toggle('active');
        });
    }

    // Sticky Header
    window.addEventListener('scroll', () => {
        const header = document.querySelector('header');
        if (window.scrollY > 100) {
            header.classList.add('sticky');
        } else {
            header.classList.remove('sticky');
        }
    });

    // FAQ Accordion
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        if (question) {
            question.addEventListener('click', () => {
                faqItems.forEach(otherItem => {
                    if (otherItem !== item) {
                        otherItem.classList.remove('active');
                    }
                });
                item.classList.toggle('active');
            });
        }
    });

    // Scroll Top Button
    const scrollTopBtn = document.getElementById('scroll-top');
    
    if (scrollTopBtn) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 300) {
                scrollTopBtn.classList.add('show');
            } else {
                scrollTopBtn.classList.remove('show');
            }
        });
        
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // Smooth Scrolling for Anchor Links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                window.scrollTo({
                    top: target.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                if (nav) {
                    nav.classList.remove('active');
                }
            }
        });
    });

    // Form Validation
    $(document).on('submit', '.contact-form', function(e) {
        e.preventDefault();
        
        const form = $(this);
        let isValid = true;
        
        form.find('.error-message').remove();
        
        const name = form.find('input[name="name"]').val().trim();
        const email = form.find('input[name="email"]').val().trim();
        const phone = form.find('input[name="phone"]').val().trim();
        const message = form.find('textarea[name="message"]').val().trim();
        
        if (name === '') {
            form.find('input[name="name"]').after('<span class="error-message">يرجى إدخال الاسم</span>');
            isValid = false;
        }
        
        if (email === '') {
            form.find('input[name="email"]').after('<span class="error-message">يرجى إدخال البريد الإلكتروني</span>');
            isValid = false;
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            form.find('input[name="email"]').after('<span class="error-message">يرجى إدخال بريد إلكتروني صحيح</span>');
            isValid = false;
        }
        
        if (phone === '') {
            form.find('input[name="phone"]').after('<span class="error-message">يرجى إدخال رقم الهاتف</span>');
            isValid = false;
        }
        
        if (message === '') {
            form.find('textarea[name="message"]').after('<span class="error-message">يرجى إدخال الرسالة</span>');
            isValid = false;
        }
        
        if (isValid) {
            form[0].submit();
        }
    });

    // Remove error messages on input
    $(document).on('input', '.contact-form input, .contact-form textarea', function() {
        $(this).siblings('.error-message').remove();
    });

})(jQuery);