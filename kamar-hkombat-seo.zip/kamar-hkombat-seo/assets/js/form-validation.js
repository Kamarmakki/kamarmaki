(function($) {
    'use strict';

    // التحقق من صحة نموذج الاتصال
    function validateContactForm(form) {
        let isValid = true;
        const name = form.find('input[name="name"]').val().trim();
        const email = form.find('input[name="email"]').val().trim();
        const phone = form.find('input[name="phone"]').val().trim();
        const message = form.find('textarea[name="message"]').val().trim();

        // إزالة رسائل الخطأ السابقة
        form.find('.error-message').remove();

        // التحقق من الاسم
        if (name === '') {
            form.find('input[name="name"]').after('<span class="error-message" style="color: red;">يرجى إدخال الاسم</span>');
            isValid = false;
        } else if (name.length < 3) {
            form.find('input[name="name"]').after('<span class="error-message" style="color: red;">الاسم يجب أن يكون 3 أحرف على الأقل</span>');
            isValid = false;
        }

        // التحقق من البريد الإلكتروني
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email === '') {
            form.find('input[name="email"]').after('<span class="error-message" style="color: red;">يرجى إدخال البريد الإلكتروني</span>');
            isValid = false;
        } else if (!emailRegex.test(email)) {
            form.find('input[name="email"]').after('<span class="error-message" style="color: red;">يرجى إدخال بريد إلكتروني صحيح</span>');
            isValid = false;
        }

        // التحقق من رقم الهاتف
        const phoneRegex = /^[\d\s\-\+\(\)]+$/;
        if (phone === '') {
            form.find('input[name="phone"]').after('<span class="error-message" style="color: red;">يرجى إدخال رقم الهاتف</span>');
            isValid = false;
        } else if (!phoneRegex.test(phone)) {
            form.find('input[name="phone"]').after('<span class="error-message" style="color: red;">يرجى إدخال رقم هاتف صحيح</span>');
            isValid = false;
        }

        // التحقق من الرسالة
        if (message === '') {
            form.find('textarea[name="message"]').after('<span class="error-message" style="color: red;">يرجى إدخال الرسالة</span>');
            isValid = false;
        } else if (message.length < 10) {
            form.find('textarea[name="message"]').after('<span class="error-message" style="color: red;">الرسالة يجب أن تكون 10 أحرف على الأقل</span>');
            isValid = false;
        }

        return isValid;
    }

    // إرسال نموذج الاتصال
    $(document).on('submit', '.contact-form', function(e) {
        e.preventDefault();
        
        const form = $(this);
        
        if (validateContactForm(form)) {
            // إظهار مؤشر التحميل
            const submitButton = form.find('button[type="submit"]');
            const originalText = submitButton.text();
            submitButton.prop('disabled', true).text('جاري الإرسال...');

            // جمع البيانات
            const formData = new FormData(form[0]);
            
            // إرسال البيانات
            $.ajax({
                type: 'POST',
                url: form.attr('action'),
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    // إخفاء النموذج وعرض رسالة النجاح
                    form.fadeOut(function() {
                        form.html('<div class="success-message" style="color: green; text-align: center; padding: 20px;">تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.</div>').fadeIn();
                    });
                },
                error: function() {
                    // عرض رسالة الخطأ
                    form.find('.form-messages').html('<div class="error-message" style="color: red; text-align: center; padding: 20px;">حدث خطأ أثناء الإرسال. يرجى المحاولة مرة أخرى.</div>');
                },
                complete: function() {
                    // استعادة زر الإرسال
                    submitButton.prop('disabled', false).text(originalText);
                }
            });
        }
    });

    // إزالة رسائل الخطأ عند البدء في الكتابة
    $(document).on('input', '.contact-form input, .contact-form textarea', function() {
        $(this).siblings('.error-message').remove();
    });

})(jQuery);