(function($) {
    'use strict';

    // Mobile Navigation
    class MobileNavigation {
        constructor() {
            this.menuToggle = document.querySelector('.mobile-menu-btn');
            this.menu = document.querySelector('nav');
            this.menuItems = document.querySelectorAll('nav ul li a');
            
            this.init();
        }
        
        init() {
            if (this.menuToggle) {
                this.menuToggle.addEventListener('click', () => this.toggleMenu());
            }
            
            // Close menu when clicking on a link
            this.menuItems.forEach(item => {
                item.addEventListener('click', () => this.closeMenu());
            });
            
            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!this.menu.contains(e.target) && !this.menuToggle.contains(e.target)) {
                    this.closeMenu();
                }
            });
        }
        
        toggleMenu() {
            this.menu.classList.toggle('active');
            this.menuToggle.classList.toggle('active');
        }
        
        closeMenu() {
            this.menu.classList.remove('active');
            this.menuToggle.classList.remove('active');
        }
    }

    // Sticky Navigation
    class StickyNavigation {
        constructor() {
            this.header = document.querySelector('header');
            this.lastScroll = 0;
            
            this.init();
        }
        
        init() {
            window.addEventListener('scroll', () => this.handleScroll());
        }
        
        handleScroll() {
            const currentScroll = window.pageYOffset;
            
            if (currentScroll > 100) {
                this.header.classList.add('sticky');
                
                if (currentScroll > this.lastScroll && currentScroll > 300) {
                    this.header.classList.add('sticky-hidden');
                } else {
                    this.header.classList.remove('sticky-hidden');
                }
            } else {
                this.header.classList.remove('sticky');
                this.header.classList.remove('sticky-hidden');
            }
            
            this.lastScroll = currentScroll;
        }
    }

    // Smooth Scroll
    class SmoothScroll {
        constructor() {
            this.links = document.querySelectorAll('a[href^="#"]');
            
            this.init();
        }
        
        init() {
            this.links.forEach(link => {
                link.addEventListener('click', (e) => this.handleClick(e));
            });
        }
        
        handleClick(e) {
            e.preventDefault();
            
            const targetId = link.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('header').offsetHeight;
                const targetPosition = targetElement.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Update URL without reload
                history.pushState(null, null, targetId);
            }
        }
    }

    // Initialize all navigation components
    document.addEventListener('DOMContentLoaded', () => {
        new MobileNavigation();
        new StickyNavigation();
        new SmoothScroll();
    });

})(jQuery);