<?php
// كل الكود هنا بدون أي ?>
// لا نغلق الوسم في نهاية الملف
function my_function() {
    // كود
}
add_action('wp_footer', 'my_function');