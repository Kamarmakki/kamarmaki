<?php
/**
 * قسم الخدمات
 */
?>
<section id="services" class="section-padding">
    <div class="container">
        <h2 class="section-title text-center">خدماتنا</h2>
        <p class="section-subtitle text-center">نقدم حلولاً متكاملة لتحسين ظهور موقعك في محركات البحث</p>
        
        <div class="grid-3">
            <div class="card service-card">
                <div class="icon-box">
                    <i class="fas fa-search"></i>
                </div>
                <h3>تحليل سيو شامل</h3>
                <p>مراجعة فنية كاملة للموقع مع تقرير 20 صفحة واضح يحلل جميع جوانب موقعك ويقدم توصيات دقيقة للتحسين.</p>
                <a href="#contact" class="btn btn-primary mt-4">اطلب الخدمة</a>
            </div>
            
            <div class="card service-card">
                <div class="icon-box">
                    <i class="fas fa-key"></i>
                </div>
                <h3>أبحاث الكلمات المفتاحية</h3>
                <p>50 كلمة مفتاحية مدروسة مع تحليل المنافسين واختيار أفضل الكلمات التي تضمن لك تصدر نتائج البحث.</p>
                <a href="#contact" class="btn btn-primary mt-4">اطلب الخدمة</a>
            </div>
            
            <div class="card service-card">
                <div class="icon-box">
                    <i class="fas fa-link"></i>
                </div>
                <h3>بناء باك لينك</h3>
                <p>روابط قوية من مواقع عربية موثوقة تعزز من سلطة موقعك وتزيد من ثقة محركات البحث في محتواك.</p>
                <a href="#contact" class="btn btn-primary mt-4">اطلب الخدمة</a>
            </div>
        </div>
    </div>
</section>