<?php
/**
 * قسم الأسعار والباقات
 */
?>
<section id="pricing" class="section-padding">
    <div class="container">
        <h2 class="section-title text-center">الباقات والأسعار</h2>
        <p class="section-subtitle text-center">اختر الباقة التي تناسب احتياجات عملك</p>
        
        <div class="grid-3">
            <div class="card pricing-card">
                <div class="pricing-header">
                    <h3>الباقة المبتدئة</h3>
                    <div class="pricing-price">999 ريال<span>/شهر</span></div>
                </div>
                <div class="pricing-body">
                    <ul class="pricing-features">
                        <li>تحليل سيو شامل</li>
                        <li>5 كلمات مفتاحية</li>
                        <li>تحسين 3 صفحات</li>
                        <li>تقرير شهري</li>
                        <li>دعم عبر البريد</li>
                    </ul>
                    <a href="#contact" class="btn btn-primary">اختر الباقة</a>
                </div>
            </div>
            
            <div class="card pricing-card featured">
                <div class="pricing-header">
                    <h3>الباقة المتقدمة</h3>
                    <div class="pricing-price">1999 ريال<span>/شهر</span></div>
                </div>
                <div class="pricing-body">
                    <ul class="pricing-features">
                        <li>تحليل سيو متقدم</li>
                        <li>15 كلمة مفتاحية</li>
                        <li>تحسين 10 صفحات</li>
                        <li>5 باك لينك شهرياً</li>
                        <li>تقرير أسبوعي</li>
                        <li>دعم عبر الهاتف</li>
                    </ul>
                    <a href="#contact" class="btn btn-primary">اختر الباقة</a>
                </div>
            </div>
            
            <div class="card pricing-card">
                <div class="pricing-header">
                    <h3>الباقة الاحترافية</h3>
                    <div class="pricing-price">3999 ريال<span>/شهر</span></div>
                </div>
                <div class="pricing-body">
                    <ul class="pricing-features">
                        <li>تحليل سيو احترافي</li>
                        <li>30 كلمة مفتاحية</li>
                        <li>تحسين 20 صفحات</li>
                        <li>15 باك لينك شهرياً</li>
                        <li>تقرير يومي</li>
                        <li>دعم على مدار الساعة</li>
                        <li>مدير حساب مخصص</li>
                    </ul>
                    <a href="#contact" class="btn btn-primary">اختر الباقة</a>
                </div>
            </div>
        </div>
    </div>
</section>