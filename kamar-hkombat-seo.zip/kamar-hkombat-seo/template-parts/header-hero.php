<?php
/**
 * Template part for displaying hero section
 *
 * @package Kamar_Hkombat
 */

$hero_title = get_theme_mod('kamar_hkombat_hero_title', 'أول منصة عربية متكاملة لخدمات السيو');
$hero_subtitle = get_theme_mod('kamar_hkombat_hero_subtitle', 'حقّق أعلى تصنيف في جوجل مع خدمات تحسين محركات البحث الاحترافية');
$hero_button1_text = get_theme_mod('kamar_hkombat_hero_button1_text', 'ابدأ الآن');
$hero_button1_url = get_theme_mod('kamar_hkombat_hero_button1_url', '#contact');
$hero_button2_text = get_theme_mod('kamar_hkombat_hero_button2_text', 'تعرف على خدماتنا');
$hero_button2_url = get_theme_mod('kamar_hkombat_hero_button2_url', '#services');
$hero_background = get_theme_mod('kamar_hkombat_hero_background', get_template_directory_uri() . '/images/hero-bg.jpg');
?>

<section class="hero" style="background-image: url('<?php echo esc_url($hero_background); ?>');">
    <div class="container">
        <div class="hero-content text-center">
            <h1><?php echo esc_html($hero_title); ?></h1>
            <p><?php echo esc_html($hero_subtitle); ?></p>
            <div class="hero-buttons">
                <a href="<?php echo esc_url($hero_button1_url); ?>" class="btn btn-primary"><?php echo esc_html($hero_button1_text); ?></a>
                <a href="<?php echo esc_url($hero_button2_url); ?>" class="btn btn-secondary"><?php echo esc_html($hero_button2_text); ?></a>
            </div>
        </div>
    </div>
</section>