<?php
/**
 * قسم الأسئلة الشائعة
 */
?>
<section id="faq" class="section-padding">
    <div class="container">
        <h2 class="section-title text-center">الأسئلة الشائعة</h2>
        <p class="section-subtitle text-center">إجابات على الأسئلة الأكثر شيوعاً حول خدماتنا</p>
        
        <div class="faq-container">
            <div class="faq-item">
                <div class="faq-question">
                    <span>ما هي مدة العقد؟</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>نقدم عقود مرنة تبدأ من 3 أشهر وتصل إلى سنة حسب احتياجاتك. يمكنك تجديد العقد أو تعديله بناءً على نتائج الحملة التسويقية.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    <span>متى أرى نتائج تحسين محركات البحث؟</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>النتائج الأولية تظهر بعد 3-4 أشهر من بدء العمل، لكن النتائج الملموسة والمستدامة تحتاج من 6-9 أشهر. نقدم تقارير دورية لمتابعة التقدم.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    <span>هل تضمنون التصدر الأول في نتائج البحث؟</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>لا يمكن لأي شركة ضمان التصدر الأول لأن خوارزميات جوجل تتغير باستمرار، لكننا نضمن تحسين ترتيب موقعك بشكل ملحوظ وزيادة حركة المرور العضوية.</p>
                </div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">
                    <span>هل يمكنني إلغاء الخدمة في أي وقت؟</span>
                    <i class="fas fa-chevron-down"></i>
                </div>
                <div class="faq-answer">
                    <p>نعم، يمكنك إلغاء الخدمة في نهاية فترة العقد. نعمل بشفافية كاملة ولا توجد رسوم إلغاء مخفية.</p>
                </div>
            </div>
        </div>
    </div>
</section>