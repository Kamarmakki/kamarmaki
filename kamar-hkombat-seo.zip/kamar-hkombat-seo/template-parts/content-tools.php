<?php
/**
 * قسم الأدوات المجانية
 */
?>
<section id="tools" class="section-padding">
    <div class="container">
        <h2 class="section-title text-center">أدواتنا المجانية</h2>
        <p class="section-subtitle text-center">استخدم أدواتنا المجانية لتحسين أداء موقعك بنفسك</p>
        
        <div class="grid-4">
            <div class="card tool-card">
                <i class="fas fa-tachometer-alt"></i>
                <h4>مدقق السرعة</h4>
                <p>حلل سرعة تحميل موقعك واحصل على توصيات لتحسينها</p>
                <a href="#" class="btn btn-primary mt-2">استخدم الآن</a>
            </div>
            
            <div class="card tool-card">
                <i class="fas fa-unlink"></i>
                <h4>مدقق الروابط المكسورة</h4>
                <p>اكتشف الروابط المعطلة في موقعك وأصلحها بسهولة</p>
                <a href="#" class="btn btn-primary mt-2">استخدم الآن</a>
            </div>
            
            <div class="card tool-card">
                <i class="fas fa-file-alt"></i>
                <h4>مولد Meta Description</h4>
                <p>أنشأ أوصافاً meta جذابة ومحسّنة لمحركات البحث</p>
                <a href="#" class="btn btn-primary mt-2">استخدم الآن</a>
            </div>
            
            <div class="card tool-card">
                <i class="fas fa-tags"></i>
                <h4>مدقق الوسوم</h4>
                <p>تحقق من صحة وسوم HTML في موقعك وحسّنها</p>
                <a href="#" class="btn btn-primary mt-2">استخدم الآن</a>
            </div>
        </div>
    </div>
</section>