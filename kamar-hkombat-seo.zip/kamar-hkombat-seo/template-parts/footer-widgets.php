<?php
/**
 * Template part for displaying footer widgets
 *
 * @package Kamar_Hkombat
 */

$footer_columns = get_theme_mod('kamar_hkombat_footer_columns', 4);
?>

<div class="footer-widgets">
    <div class="container">
        <div class="grid-<?php echo esc_attr($footer_columns); ?>">
            <?php if (is_active_sidebar('footer-1')) : ?>
                <div class="footer-col">
                    <?php dynamic_sidebar('footer-1'); ?>
                </div>
            <?php endif; ?>
            
            <?php if (is_active_sidebar('footer-2')) : ?>
                <div class="footer-col">
                    <?php dynamic_sidebar('footer-2'); ?>
                </div>
            <?php endif; ?>
            
            <?php if (is_active_sidebar('footer-3')) : ?>
                <div class="footer-col">
                    <?php dynamic_sidebar('footer-3'); ?>
                </div>
            <?php endif; ?>
            
            <?php if (is_active_sidebar('footer-4')) : ?>
                <div class="footer-col">
                    <?php dynamic_sidebar('footer-4'); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>