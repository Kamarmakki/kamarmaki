<?php
/**
 * جزء عدم وجود نتائج
 */
?>
<div class="no-results">
    <header class="page-header">
        <h1 class="page-title"><?php _e('لا يوجد شيء للعرض', 'kamar-hkombat'); ?></h1>
    </header>
    
    <div class="page-content">
        <?php if (is_home() && current_user_can('publish_posts')) : ?>
            <p><?php printf(__('جاهز لنشر أول مقال لك؟ <a href="%s">ابدأ من هنا</a>.', 'kamar-hkombat'), esc_url(admin_url('post-new.php'))); ?></p>
        <?php elseif (is_search()) : ?>
            <p><?php _e('عذراً، لم نجد أي نتائج تطابق بحثك. يرجى المحاولة مرة أخرى بكلمات مختلفة.', 'kamar-hkombat'); ?></p>
            <?php get_search_form(); ?>
        <?php else : ?>
            <p><?php _e('يبدو أننا لا نستطيع العثور على ما تبحث عنه. ربما البحث يمكن أن يساعد.', 'kamar-hkombat'); ?></p>
            <?php get_search_form(); ?>
        <?php endif; ?>
    </div>
</div>