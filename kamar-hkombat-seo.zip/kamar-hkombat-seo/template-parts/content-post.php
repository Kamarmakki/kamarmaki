<?php
/**
 * جزء عرض المقالات
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php if (has_post_thumbnail()) : ?>
        <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
        </div>
    <?php endif; ?>
    
    <header class="entry-header">
        <?php the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>'); ?>
        
        <?php if ('post' === get_post_type()) : ?>
            <div class="entry-meta">
                <span class="posted-on"><?php echo get_the_date(); ?></span>
                <span class="byline">بواسطة <?php echo get_the_author(); ?></span>
            </div>
        <?php endif; ?>
    </header>
    
    <div class="entry-content">
        <?php the_excerpt(); ?>
    </div>
    
    <footer class="entry-footer">
        <a href="<?php the_permalink(); ?>" class="btn btn-primary">اقرأ المزيد</a>
    </footer>
</article>