<?php
/**
 * قسم الاتصال
 */
?>
<section id="contact" class="section-padding">
    <div class="container">
        <h2 class="section-title text-center">تواصل معنا</h2>
        <p class="section-subtitle text-center">احصل على تحليل مجاني لموقعك واستشارة من خبرائنا</p>
        
        <form class="contact-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="contact_form">
            <?php wp_nonce_field('contact_form_nonce', 'contact_nonce'); ?>
            
            <div class="grid-2">
                <div class="form-group">
                    <input type="text" name="name" class="form-control" placeholder="الاسم الكامل" required>
                </div>
                <div class="form-group">
                    <input type="email" name="email" class="form-control" placeholder="البريد الإلكتروني" required>
                </div>
            </div>
            <div class="form-group">
                <input type="tel" name="phone" class="form-control" placeholder="رقم الهاتف" required>
            </div>
            <div class="form-group">
                <input type="url" name="website" class="form-control" placeholder="رابط موقعك" required>
            </div>
            <div class="form-group">
                <textarea name="message" class="form-control" placeholder="اكتب رسالتك هنا..." required></textarea>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">إرسال الطلب</button>
            </div>
        </form>
    </div>
</section>